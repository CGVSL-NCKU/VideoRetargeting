#pragma once
#pragma comment(linker, "/SUBSYSTEM:CONSOLE /ENTRY:WinMainCRTStartup")
#include "main.h"
#include "DotNetUtilities.h"

manager_image sys_image;
manager_video sys_video;

int last_X , last_Y;

namespace VideoResizing {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected: 
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;

	private: System::Windows::Forms::ToolStripMenuItem^  loadVideoToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
	private: GLAPPanel::HKGLAPPanelControl^  hkglapPanelControl1;

	private: System::Windows::Forms::ToolStripMenuItem^  renderToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  TrajectoryToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  MeshToolStripMenuItem;


	private: System::Windows::Forms::TrackBar^  trackBar1;

	private: System::Windows::Forms::Timer^  timer1;
	private: System::Windows::Forms::ToolStripMenuItem^  saveVideoToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  saliencyToolStripMenuItem;

	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog2;



	private: System::Windows::Forms::ToolStripMenuItem^  loadTrajectoryToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  halfSizeVideoToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog2;
	private: System::Windows::Forms::ToolStripMenuItem^  loadMeshToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog3;
	private: System::Windows::Forms::ToolStripMenuItem^  loadCropVideoToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog4;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog5;
	private: System::Windows::Forms::ToolStripMenuItem^  saveMeshToolStripMenuItem;


	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->loadVideoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveVideoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->loadTrajectoryToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->halfSizeVideoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->loadMeshToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->loadCropVideoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->renderToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->TrajectoryToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->MeshToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saliencyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->hkglapPanelControl1 = (gcnew GLAPPanel::HKGLAPPanelControl());
			this->trackBar1 = (gcnew System::Windows::Forms::TrackBar());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->saveFileDialog2 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->openFileDialog2 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->openFileDialog3 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->openFileDialog4 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->openFileDialog5 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveMeshToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->trackBar1))->BeginInit();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::Color::Transparent;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fileToolStripMenuItem, 
				this->renderToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(984, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(7) {this->loadVideoToolStripMenuItem, 
				this->saveVideoToolStripMenuItem, this->loadTrajectoryToolStripMenuItem, this->halfSizeVideoToolStripMenuItem, this->loadMeshToolStripMenuItem, 
				this->loadCropVideoToolStripMenuItem, this->saveMeshToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(39, 20);
			this->fileToolStripMenuItem->Text = L"File";
			// 
			// loadVideoToolStripMenuItem
			// 
			this->loadVideoToolStripMenuItem->Name = L"loadVideoToolStripMenuItem";
			this->loadVideoToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->loadVideoToolStripMenuItem->Text = L"Load Video";
			this->loadVideoToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::loadVideoToolStripMenuItem_Click);
			// 
			// saveVideoToolStripMenuItem
			// 
			this->saveVideoToolStripMenuItem->Name = L"saveVideoToolStripMenuItem";
			this->saveVideoToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->saveVideoToolStripMenuItem->Text = L"Save Video";
			this->saveVideoToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveVideoToolStripMenuItem_Click);
			// 
			// loadTrajectoryToolStripMenuItem
			// 
			this->loadTrajectoryToolStripMenuItem->Name = L"loadTrajectoryToolStripMenuItem";
			this->loadTrajectoryToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->loadTrajectoryToolStripMenuItem->Text = L"Load Trajectory";
			this->loadTrajectoryToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::loadTrajectoryToolStripMenuItem_Click);
			// 
			// halfSizeVideoToolStripMenuItem
			// 
			this->halfSizeVideoToolStripMenuItem->Name = L"halfSizeVideoToolStripMenuItem";
			this->halfSizeVideoToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->halfSizeVideoToolStripMenuItem->Text = L"Half Size Video";
			this->halfSizeVideoToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::halfSizeVideoToolStripMenuItem_Click);
			// 
			// loadMeshToolStripMenuItem
			// 
			this->loadMeshToolStripMenuItem->Name = L"loadMeshToolStripMenuItem";
			this->loadMeshToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->loadMeshToolStripMenuItem->Text = L"Load mesh";
			this->loadMeshToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::loadMeshToolStripMenuItem_Click);
			// 
			// loadCropVideoToolStripMenuItem
			// 
			this->loadCropVideoToolStripMenuItem->Name = L"loadCropVideoToolStripMenuItem";
			this->loadCropVideoToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->loadCropVideoToolStripMenuItem->Text = L"Load Crop video";
			this->loadCropVideoToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::loadCropVideoToolStripMenuItem_Click);
			// 
			// renderToolStripMenuItem
			// 
			this->renderToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->TrajectoryToolStripMenuItem, 
				this->MeshToolStripMenuItem, this->saliencyToolStripMenuItem});
			this->renderToolStripMenuItem->Name = L"renderToolStripMenuItem";
			this->renderToolStripMenuItem->Size = System::Drawing::Size(61, 20);
			this->renderToolStripMenuItem->Text = L"Render";
			// 
			// TrajectoryToolStripMenuItem
			// 
			this->TrajectoryToolStripMenuItem->CheckOnClick = true;
			this->TrajectoryToolStripMenuItem->Name = L"TrajectoryToolStripMenuItem";
			this->TrajectoryToolStripMenuItem->Size = System::Drawing::Size(132, 22);
			this->TrajectoryToolStripMenuItem->Text = L"Trajectory";
			this->TrajectoryToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::TrajectoryToolStripMenuItem_CheckedChanged);
			// 
			// MeshToolStripMenuItem
			// 
			this->MeshToolStripMenuItem->CheckOnClick = true;
			this->MeshToolStripMenuItem->Name = L"MeshToolStripMenuItem";
			this->MeshToolStripMenuItem->Size = System::Drawing::Size(132, 22);
			this->MeshToolStripMenuItem->Text = L"Mesh";
			this->MeshToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::MeshToolStripMenuItem_CheckedChanged);
			// 
			// saliencyToolStripMenuItem
			// 
			this->saliencyToolStripMenuItem->CheckOnClick = true;
			this->saliencyToolStripMenuItem->Name = L"saliencyToolStripMenuItem";
			this->saliencyToolStripMenuItem->Size = System::Drawing::Size(132, 22);
			this->saliencyToolStripMenuItem->Text = L"Saliency";
			this->saliencyToolStripMenuItem->CheckedChanged += gcnew System::EventHandler(this, &Form1::saliencyToolStripMenuItem_CheckedChanged);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			this->openFileDialog1->Filter = L"Avi File|*.avi";
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->Filter = L"Avi File|*.avi";
			// 
			// hkglapPanelControl1
			// 
			this->hkglapPanelControl1->Accum_Buffer = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->AllowDrop = true;
			this->hkglapPanelControl1->Alpha_Buffer = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Aux_Buffer = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->BackColor = System::Drawing::Color::White;
			this->hkglapPanelControl1->Color_Bit = GLAPPanel::COLORBITS::COLOR_BIT_32;
			this->hkglapPanelControl1->Default_Setting = GLAPPanel::BOOLTYPE::True;
			this->hkglapPanelControl1->Default_Viewport = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Depth_Bit = GLAPPanel::DEPTHBITS::DEPTH_BIT_32;
			this->hkglapPanelControl1->Draw_Axis = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Draw_Axis_Pos = GLAPPanel::DRAWAXISPOS::Corner;
			this->hkglapPanelControl1->Draw_Grid = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Font2D_Enable = GLAPPanel::BOOLTYPE::True;
			this->hkglapPanelControl1->Font2D_Type->Bold = GLAPPanel::FONTBOLD::DONTCARE;
			this->hkglapPanelControl1->Font2D_Type->Charset = GLAPPanel::FONTCHARSET::ANSI_SET;
			this->hkglapPanelControl1->Font2D_Type->Color = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->hkglapPanelControl1->Font2D_Type->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold));
			this->hkglapPanelControl1->Font2D_Type->Pitch = GLAPPanel::FONTPITCH::DEFAULT;
			this->hkglapPanelControl1->Font3D_DrawMode = GLAPPanel::OUTLINEFONTDRAWMODE::FONT_POLYGONS;
			this->hkglapPanelControl1->Font3D_Enable = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Font3D_Type->Bold = GLAPPanel::FONTBOLD::DONTCARE;
			this->hkglapPanelControl1->Font3D_Type->Charset = GLAPPanel::FONTCHARSET::ANSI_SET;
			this->hkglapPanelControl1->Font3D_Type->Color = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->hkglapPanelControl1->Font3D_Type->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold));
			this->hkglapPanelControl1->Font3D_Type->Pitch = GLAPPanel::FONTPITCH::DEFAULT;
			this->hkglapPanelControl1->Location = System::Drawing::Point(0, 23);
			this->hkglapPanelControl1->Name = L"hkglapPanelControl1";
			this->hkglapPanelControl1->SceneSlide_KeyBtn = GLAPPanel::KEYMODIFIERS::None;
			this->hkglapPanelControl1->SceneSlide_MouseBtn = System::Windows::Forms::MouseButtons::Middle;
			this->hkglapPanelControl1->SceneSlide_Resolution = 100;
			this->hkglapPanelControl1->SceneZoom_Resolution = 1000;
			this->hkglapPanelControl1->Size = System::Drawing::Size(990, 475);
			this->hkglapPanelControl1->Stencil_Buffer = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->TabIndex = 1;
			this->hkglapPanelControl1->Track_KeyBtn = GLAPPanel::KEYMODIFIERS::None;
			this->hkglapPanelControl1->Track_MouseBtn = System::Windows::Forms::MouseButtons::Right;
			this->hkglapPanelControl1->Viewport_Change = GLAPPanel::BOOLTYPE::False;
			this->hkglapPanelControl1->Viewport_Control = GLAPPanel::BOOLTYPE::True;
			this->hkglapPanelControl1->Viewport_Tag = GLAPPanel::BOOLTYPE::True;
			this->hkglapPanelControl1->Load += gcnew System::EventHandler(this, &Form1::hkglapPanelControl1_Load);
			this->hkglapPanelControl1->DoubleClick += gcnew System::EventHandler(this, &Form1::hkglapPanelControl1_DoubleClick);
			this->hkglapPanelControl1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::hkglapPanelControl1_Paint);
			this->hkglapPanelControl1->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::hkglapPanelControl1_MouseMove);
			this->hkglapPanelControl1->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::hkglapPanelControl1_MouseDown);
			this->hkglapPanelControl1->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::hkglapPanelControl1_DragDrop);
			this->hkglapPanelControl1->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::hkglapPanelControl1_KeyUp);
			this->hkglapPanelControl1->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::hkglapPanelControl1_MouseUp);
			this->hkglapPanelControl1->DragEnter += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::hkglapPanelControl1_DragEnter);
			this->hkglapPanelControl1->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::hkglapPanelControl1_KeyDown);
			// 
			// trackBar1
			// 
			this->trackBar1->Location = System::Drawing::Point(0, 504);
			this->trackBar1->Name = L"trackBar1";
			this->trackBar1->Size = System::Drawing::Size(984, 45);
			this->trackBar1->TabIndex = 2;
			this->trackBar1->ValueChanged += gcnew System::EventHandler(this, &Form1::trackBar1_ValueChanged);
			this->trackBar1->Scroll += gcnew System::EventHandler(this, &Form1::trackBar1_Scroll);
			// 
			// timer1
			// 
			this->timer1->Interval = 30;
			this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
			// 
			// openFileDialog2
			// 
			this->openFileDialog2->FileName = L"openFileDialog2";
			this->openFileDialog2->Multiselect = true;
			// 
			// openFileDialog3
			// 
			this->openFileDialog3->FileName = L"openFileDialog3";
			this->openFileDialog3->Filter = L"Mesh File|*.msh";
			// 
			// openFileDialog4
			// 
			this->openFileDialog4->FileName = L"openFileDialog4";
			this->openFileDialog4->Filter = L"Avi File|*.avi";
			// 
			// openFileDialog5
			// 
			this->openFileDialog5->FileName = L"openFileDialog5";
			// 
			// saveMeshToolStripMenuItem
			// 
			this->saveMeshToolStripMenuItem->Name = L"saveMeshToolStripMenuItem";
			this->saveMeshToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->saveMeshToolStripMenuItem->Text = L"Save Mesh";
			this->saveMeshToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveMeshToolStripMenuItem_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(984, 562);
			this->Controls->Add(this->trackBar1);
			this->Controls->Add(this->hkglapPanelControl1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->Text = L"Video Resizing";
			this->Resize += gcnew System::EventHandler(this, &Form1::Form1_Resize);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->trackBar1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void loadImageToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			
			 }
private: System::Void hkglapPanelControl1_Load(System::Object^  sender, System::EventArgs^  e) {

			 sys_image.OpenGLinitial();
			 sys_image.PanelResize(hkglapPanelControl1->Size.Width , hkglapPanelControl1->Size.Height);
		 }
private: System::Void hkglapPanelControl1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {

			 if(sys_video.manager_id == 1)  sys_video.Render( sys_video.Render_segmentation,sys_video.Render_edge ,sys_video.Render_Saliency);
			 else                                                                                                 ;

		 }
private: System::Void Form1_Resize(System::Object^  sender, System::EventArgs^  e) {

			 hkglapPanelControl1->Location = System::Drawing::Point(0 , 23);
			 hkglapPanelControl1->Size = System::Drawing::Size(Size.Width-10, Size.Height - 102);

			 trackBar1->Location = System::Drawing::Point(4, Size.Height - 96);
			 trackBar1->Size = System::Drawing::Size(Size.Width - 8 , 45);

			 sys_image.panelSize.set((float)hkglapPanelControl1->Size.Width , (float)hkglapPanelControl1->Size.Height);
			 sys_video.panelSize.set((float)hkglapPanelControl1->Size.Width , (float)hkglapPanelControl1->Size.Height);
			 sys_image.PanelResize((float)hkglapPanelControl1->Size.Width , (float)hkglapPanelControl1->Size.Height);
			 hkglapPanelControl1->Refresh();
		 }
private: System::Void hkglapPanelControl1_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

			
		 }
private: System::Void hkglapPanelControl1_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
 
			 if (e->Button == System::Windows::Forms::MouseButtons::Left && Control::ModifierKeys == Keys::None)
			 {
				 vector2 Move((float)(e->X - last_X) , (float)(e->Y - last_Y));

				 if (Move.length() < 300.0f)
				 {

					 if(sys_video.manager_id == 1) sys_video.ImagePos += Move;
					 else                                                    ;
				 }
					 

				 hkglapPanelControl1->Refresh();
			 }


			 if (e->Button == System::Windows::Forms::MouseButtons::Right && Control::ModifierKeys == Keys::None)
			 {
				 if(sys_video.manager_id == 1) sys_video.Zoom -= (last_Y - e->Y) / 100.0f;
				 else                                                                    ;

				 hkglapPanelControl1->Refresh();
			 }


			 last_X = e->X;
			 last_Y = e->Y;

		 }
private: System::Void TrajectoryToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {

			 if(TrajectoryToolStripMenuItem->Checked == true)    
			 {
				 sys_video.Render_segmentation  = 1;
			 }
			 else
			 {
				 sys_video.Render_segmentation  = 0;
			 }
			 
			 hkglapPanelControl1->Refresh();
		 }
private: System::Void MeshToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {

			 if(MeshToolStripMenuItem->Checked == true)     
			 {
				 sys_video.Render_edge = 1;
				 sys_video.Render_mesh = 1;
			 }
			 else                          
			 {
				 sys_video.Render_edge = 0;
				 sys_video.Render_mesh = 0;
			 }

			 hkglapPanelControl1->Refresh();
		 }
private: System::Void trackBar1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
             
			 /*
			 if(sys_image.manager_id == 1)
			 {
				 sys_image.draw_patch_num = trackBar1->Value;
				 hkglapPanelControl1->Refresh();
			 }
			 */
			 
		 }

private: System::Void loadVideoToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (openFileDialog1->ShowDialog() == Windows::Forms::DialogResult::OK)
			 {
				 string filename;
				 MarshalString(openFileDialog1->FileName , filename);
				 sys_video.LoadVideo(filename);

				 trackBar1->Minimum = 0;
				 trackBar1->Maximum = sys_video.frameNum-1;
				 trackBar1->Value   = 0;

				 sys_video.manager_id = 1;
				 sys_image.manager_id = 0;


			 }
		 }
private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {

          if(sys_video.manager_id == 1)
		  {
			 if (!sys_video.saveMode)
			 {
				 int frame = sys_video.frameUpdate();

				 trackBar1->Value = frame;
				 hkglapPanelControl1->Refresh();
			 }
			 else
			 {
				

				 sys_video.setframe(sys_video.frameIdx);
				 trackBar1->Value = sys_video.frameIdx;
				 hkglapPanelControl1->Refresh();
				 sys_video.SaveFrame(true);

				 if (sys_video.frameIdx == sys_video.frameNum - 1)
				 {
					 sys_video.saveMode = false;
					 sys_video.releaseSaving();

					 return;
				 }

				 sys_video.frameIdx++;
			 }
		  }
		 }
private: System::Void hkglapPanelControl1_DoubleClick(System::Object^  sender, System::EventArgs^  e) {

			 timer1->Enabled = !timer1->Enabled;
		 }
private: System::Void trackBar1_Scroll(System::Object^  sender, System::EventArgs^  e) {

			if(sys_video.manager_id == 1)
			{
				int frame = trackBar1->Value;

				timer1->Enabled = false;
				sys_video.setframe(frame);

				hkglapPanelControl1->Refresh();
			}
			 
		 }
private: System::Void saveVideoToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if ( saveFileDialog1->ShowDialog() == Windows::Forms::DialogResult::OK )
			 {
				 string filename;
				 MarshalString(saveFileDialog1->FileName , filename);

				 //sys_video.saveMesh(filename);
				 sys_video.Zoom = 1.0f;
				 sys_video.frameIdx = 0;
				 sys_video.saveMode = true;
				 sys_video.SaveVideo(filename);
			 }
		 }
private: System::Void saliencyToolStripMenuItem_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {

			 if(saliencyToolStripMenuItem->Checked == true)     
			 {
				 sys_video.Render_Saliency = 1;
			 }
			 else                              
			 {
				 sys_video.Render_Saliency = 0;
			 }

			 hkglapPanelControl1->Refresh();
		 }

private: System::Void hkglapPanelControl1_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {


			 if (e->KeyCode == Keys::X)
			 {
				if(sys_video.manager_id == 1)  sys_video.Video_Resizing(sys_video.vWidth *0.5f , sys_video.vHeight);
			 }
				 
			

			 hkglapPanelControl1->Refresh();


		 }


private: System::Void hkglapPanelControl1_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

			 
		 }
private: System::Void hkglapPanelControl1_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {


			
		 }
private: System::Void trajectoryToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if(sys_video.manager_id == 1) sys_video.saveTrajectory();
		 }
private: System::Void loadTrajectoryToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (openFileDialog5->ShowDialog() == Windows::Forms::DialogResult::OK)
			 {
				 string filename;
				 MarshalString(openFileDialog5->FileName , filename);

				 sys_video.LoadTrajectory(filename);
			     
			 }


				 hkglapPanelControl1->Refresh();


		 }
private: System::Void halfSizeVideoToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (openFileDialog2->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
				 string filename;

				 for (Int32 i = 0 ; i < openFileDialog2->FileNames.Length ; i++)
				 {
					 MarshalString(openFileDialog2->FileNames[i] , filename);

					 // load file

					 sys_video.LoadVideo(filename);

					 sys_video.Video_Resizing(int(sys_video.vWidth*0.5),sys_video.vHeight);

					 sys_video.saveMesh(filename);
					 
					 trackBar1->Minimum = 0;
					 trackBar1->Maximum = sys_video.frameNum-1;
					 trackBar1->Value   = 0;

					 sys_video.manager_id = 1;
					 sys_image.manager_id = 0;

					 printf("%d / %d\n",i+1,openFileDialog2->FileNames.Length);
					
				 }
			 }
		 }
private: System::Void loadMeshToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (openFileDialog3->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
				 string filename;

				 MarshalString(openFileDialog3->FileName , filename);

                 sys_video.loadMesh(filename);

				 
				 trackBar1->Minimum = 0;
				 trackBar1->Maximum = sys_video.frameNum-1;
				 trackBar1->Value   = 0;

				 sys_video.resize_ratio.x = 1.0;
				 sys_video.resize_ratio.y = 1.0;

				 sys_video.manager_id = 1;
				 sys_image.manager_id = 0;
				 
				 sys_video.frameIdx = 0;

				 timer1->Enabled = 1;

				 hkglapPanelControl1->Refresh();

				 // load file

			 }
		 }
private: System::Void hkglapPanelControl1_DragEnter(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
 
			 if(e->Data->GetDataPresent(DataFormats::FileDrop))
				 e->Effect = DragDropEffects::All;
			 else
				 e->Effect = DragDropEffects::None;


		 }
private: System::Void hkglapPanelControl1_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
 
			 std::string filename;
			 array<String^>^ files = dynamic_cast< array<String^>^ >(e->Data->GetData(DataFormats::FileDrop));
			 String^ first_file = files[0];

			 MarshalString(first_file , filename);

			 int name_size = filename.size();
			 if(   (filename[name_size-3] == 'm' && filename[name_size-2] == 's' && filename[name_size-1] == 'h'))
			 {
				 sys_video.loadMesh(filename);

				 printf("framenum:%d\n",sys_video.frameNum);
				 trackBar1->Minimum = 0;
				 trackBar1->Maximum = sys_video.frameNum-1;
				 trackBar1->Value   = 0;

				 sys_video.manager_id = 1;
				 sys_image.manager_id = 0;

				 sys_video.resize_ratio.x = 1.0;
				 sys_video.resize_ratio.y = 1.0;

				 sys_video.frameIdx = 0;

				 timer1->Enabled = 1;

				 sys_video.Render_result = 1;

				 hkglapPanelControl1->Refresh();
			 }


		 }
private: System::Void loadCropVideoToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {


			 if (openFileDialog4->ShowDialog() == Windows::Forms::DialogResult::OK)
			 {
				 string filename;
				 MarshalString(openFileDialog4->FileName , filename);
				 sys_video.LoadCompareVideo(filename);

			 }
		 }
private: System::Void saveMeshToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if ( saveFileDialog2->ShowDialog() == Windows::Forms::DialogResult::OK )
			 {
				 string filename;
				 MarshalString(saveFileDialog2->FileName , filename);

				 sys_video.saveMesh(filename);
			 }


		 }
};
}

