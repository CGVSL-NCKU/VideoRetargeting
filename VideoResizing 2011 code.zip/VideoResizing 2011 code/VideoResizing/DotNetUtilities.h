#ifndef _DOTNETUTILITIES_H_
#define _DOTNETUTILITIES_H_

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Convert System::String to std::string
void MarshalString ( System::String^ s, std::string& os );

/// Get stl file extension
string get_FileExt(const string &_file_name);

/// Get stl file path without extension
string get_FilePathWithoutExt(const string &_file_name);
/*
int get_integer(const char *_char);
float get_float(const char *_char);
*/

#endif