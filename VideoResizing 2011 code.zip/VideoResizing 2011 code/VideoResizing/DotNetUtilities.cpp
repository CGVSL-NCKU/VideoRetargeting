#include "stdafx.h"
#include "DotNetUtilities.h"

void MarshalString ( System::String^ s, std::string& os )
{
   using namespace System::Runtime::InteropServices;
   const char* chars = (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
   os = chars;
   Marshal::FreeHGlobal(System::IntPtr((void*)chars));
}

string get_FileExt(const string &_file_name)
{
	string::size_type pos = 0, end_pos = 0;
	pos		= _file_name.find_last_of('.');
	end_pos	= _file_name.length();
	string ext = _file_name.substr(pos, end_pos);

	return ext;
}

string get_FilePathWithoutExt(const string &_file_name)
{
	string::size_type pos = 0;
	pos	= _file_name.find_last_of('.');	
	string filepath = _file_name.substr(0, pos);
	return filepath;
}
/*
int get_integer(const char *_char)
{
	int i = 0;
	int sum = 0;
	while(_char[i]!='\0') i++;
	i--;
	int j = 0;
	while(i>=0)
	{
		sum = sum + ((int)_char[i]-48)*pow(10.0,j);
		i--;
		j++;
	}
	return sum;
}

float get_float(const char *_char)
{
	int i = 0;
	float sum = 0;
	while(_char[i]!='.' && _char[i]!='\0') i++;
	int temp = i;
	temp--;
	int j = 0;
	while(temp>=0)
	{
		sum = sum + ((int)_char[temp]-48)*pow(10.0,j);
		temp--;
		j++;
	}
    j = i;
	while(_char[j]!='\0') j++;
	temp = i+1;
	int k = 1;
	double e = 0.0;
	while(temp < j)
	{
		int num = (int)_char[temp]-48;
		e = pow(10.0,-k);

		if(num != 0) sum = sum + num*e;
		
		temp++;
		k++;
	}

	return sum;
}
*/