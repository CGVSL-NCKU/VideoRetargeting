#ifndef EDGE_CONSTRAINT_H
#define EDGE_CONSTRAINT_H

class EdgeConstraint
{
public:
	bool active;
	vector2 vec;

	EdgeConstraint()
	{
		active = false;
		vec.set(0.0f , 0.0f);
	}

	EdgeConstraint(bool _act , vector2 _v)
	{
		set(_act , _v);
	}

	~EdgeConstraint()
	{
		set(false , vector2(0.0f , 0.0f));
	}

	void set(bool _act , vector2 _v)
	{
		active = _act;
		vec = _v;
	}
};

#endif