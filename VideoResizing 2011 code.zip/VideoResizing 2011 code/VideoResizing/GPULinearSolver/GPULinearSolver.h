#ifndef GPU_LINEAR_SOLVER_H
#define GPU_LINEAR_SOLVER_H

#include <Windows.h>
#include <stdlib.h>
#include <vector>
#include <cassert>

#include "cnc_gpu_solver.h"
#include "cnc_sparse_matrix.h"

#include "TimeRecorder.h"

extern "C"
{
	#include <cs.h>
};

using namespace std;
#pragma comment(lib, "CSparse.lib")

class IterativeSolver
{
public:
	IterativeSolver()
	{
		A = triplet = NULL;
		cols = rows = 0;
		Is_System_Stable = Is_RHS_Stable = false;

		GeneralSparseMatrix.clear();
	}

	~IterativeSolver()
	{
		deallocate();
	}

	bool IsTheSameSize(int rowNum , int colNum)
	{
		if (rows == rowNum && cols == colNum)
			return true;
		else
			return false;
	}

	void Create(int rowNum , int colNum)
	{
		rows = rowNum;
		cols = colNum;
		Is_System_Stable = Is_RHS_Stable = false;

		AllocateSystemMatrix();
		AllocateRightHandSideMatrix();
	}

	void ResetSolver(int rowNum , int colNum)
	{
		deallocate();
		Create(rowNum , colNum);
	}

	void AddSysElement(int rowIdx , int colIdx , float val)
	{
		if (rowIdx >= rows || colIdx >= cols)
			printf("Warning! An index of the system matrix is wrong! %d %d %d %d\n", rowIdx , rows , colIdx , cols );

		cs_entry(triplet , rowIdx , colIdx , val);
		Is_System_Stable = false;
	}

	void SetRightHandSideMatrix(float *m)
	{
		b = m;
		Is_RHS_Stable = false;
	}

	float GetSolution(int rowIdx)
	{
		return x[rowIdx];
	}

	void SetInitialGuess(float *m)
	{
		for (int i = 0 ; i < cols ; i++)
			x[i] = m[i];
	}

	void matrixStablization()
	{
		if (!Is_System_Stable)		LeastSquareToGeneralSparseMatrix();
		if (!Is_RHS_Stable)			ATbComputation();
	}

	void solve(float epsilon = 0.001f , int max_iter = 5000 , int blocksize = 2)	
	{
		//TimeRecorder timer;
		//timer.ResetTimer();

		matrixStablization();

		CNCGPUSolver::solve_cg(GeneralSparseMatrix, ATb, x, max_iter, epsilon, blocksize);

		//printf("non-zero elements: %d, unknown variables: %d, passed time: %f\n" , GeneralSparseMatrix.nnz() , ATb.size() , timer.PassedTime());
	}

private:
	int cols , rows;
	bool Is_System_Stable , Is_RHS_Stable;

	// Sparse/Dense matrix for GPU
	floatArray ATb , x;
	CNCSparseMatrix GeneralSparseMatrix;
	
	// Sparse/Dense matrix for CPU
	float *b;
	cs *triplet , *A;

	void deallocate()
	{
		x.clear();
		ATb.clear();

		if (A != NULL)
		{
			cs_spfree(A);
			A = NULL;
		}

		if (triplet != NULL)
		{
			cs_spfree(triplet);
			triplet = NULL;
		}

		GeneralSparseMatrix.clear();
	}

	void AllocateSystemMatrix()
	{
		x.allocate(cols);
		x.set_all(0.0f);
	
		GeneralSparseMatrix.allocate(cols , cols , CNCSparseMatrix::ROWS , false);
		triplet = cs_spalloc(rows , cols , rows , 1 , 1);
	}

	void AllocateRightHandSideMatrix()
	{
		// allocate
		ATb.allocate(cols);
		ATb.set_all(0.0f);
	}

	void LeastSquareToGeneralSparseMatrix()
	{
		cs *ATA , *AT;
		A = cs_compress(triplet);

		// --------------- Saving more memory space --------------------
		// Warning!! should be very careful, you cannot add any non-zero 
		//			 element again unless you recreate a new system!
		cs_spfree(triplet);
		triplet = NULL;
		// -------------------------------------------------------------

		AT = cs_transpose(A , 1);
		ATA = cs_multiply(AT , A);

		// release AT
		cs_spfree(AT);

		// fill in ATA matrix to General Sparse matrix
		// Warning!! it would crash here if the memory space is not enough
		int *AP = ATA->p , *AI = ATA->i;				
		float *AX = ATA->x;

		for (int i = 0 ; i < ATA->n ; i++)
			for (int j = AP[i] ; j < AP[i + 1] ; j++)
				GeneralSparseMatrix.add(i , AI[j] , AX[j]);

		// release ATA
		cs_spfree(ATA);

		Is_System_Stable = true;
	}

	//void LeastSquareToGeneralSparseMatrix()
	//{
	//	A = cs_compress(triplet);	

	//	// --------------- Saving more memory space --------------------
	//	// Warning!! should be very careful, you cannot add any non-zero 
	//	//			 element again unless you recreate a new system!
	//	cs_spfree(triplet);
	//	triplet = NULL;
	//	// -------------------------------------------------------------

	//	int *AP = A->p , *AI = A->i;
	//	float *AX = A->x;
	//	float *dense = new float[rows];

	//	memset((void *)dense , 0 , rows * sizeof(float));

	//	for (int i = 0 ; i < cols ; i++)
	//	{
	//		for (int m = AP[i] ; m < AP[i + 1] ; m++)
	//			dense[AI[m]] += AX[m];

	//		for (int j = i ; j < cols ; j++)
	//		{
	//			float val = 0.0f;

	//			for (int m = AP[j] ; m < AP[j + 1] ; m++)
	//				val += AX[m] * dense[AI[m]];

	//			if (val != 0.0f)
	//			{
	//				if (i == j)
	//					GeneralSparseMatrix.add(i , i , val);
	//				else
	//				{
	//					GeneralSparseMatrix.add(i , j , val);
	//					GeneralSparseMatrix.add(j , i , val);
	//				}
	//			}
	//		}

	//		for (int m = AP[i] ; m < AP[i + 1] ; m++)
	//			dense[AI[m]] = 0.0f;
	//	}

	//	delete [] dense;
	//	Is_System_Stable = true;
	//}

	void ATbComputation()
	{
		int *AP = A->p , *AI = A->i;
		float *AX = A->x;

		ATb.set_all(0.0f);

		for (int i = 0 ; i < A->n ; i++)
			for (int j = AP[i] ; j < AP[i + 1] ; j++)
				ATb[i] += AX[j] * b[AI[j]];			// row = AI[j];	 col = i;  val = AX[j];

		Is_RHS_Stable = true;
	}
};

#endif