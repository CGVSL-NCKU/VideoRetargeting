#ifndef EDGE_SLOPE_CONSTRAINT_H
#define EDGE_SLOPE_CONSTRAINT_H

#define MINIMUM_DELTA_X 5

class EdgeSlopeConstraint {
public:
	bool isInfiniteSlope;	// whether slope is infinite or not ( constrain x' = x )
	float slope;	// slope
	int sourceIdx;	// source vertex idx
	int targetIdx;	// target vertex idx
	float n;	// slope ratio

	vector2 vec;

	EdgeSlopeConstraint() : isInfiniteSlope(false), slope(0.0), sourceIdx(0), targetIdx(0), n(1.0) {
		vec.set(0.0f, 0.0f);
	}

	EdgeSlopeConstraint(int sourceIdx_in, int targetIdx_in, vector2 sourceVertex, vector2 targetVertex) {
		sourceIdx = sourceIdx_in;
		targetIdx = targetIdx_in;
		n = 1.0;

		float deltaX = sourceVertex.x - targetVertex.x;
		float deltaY = sourceVertex.y - targetVertex.y;
		//if(abs(deltaX) < MINIMUM_DELTA_X) {
		if(abs(deltaX) < abs(deltaY)) {
			isInfiniteSlope = true;
			slope = deltaX / deltaY;
		} else {
			isInfiniteSlope = false;
			slope = deltaY / deltaX;
		}

		vec = sourceVertex - targetVertex;

		/*
			cout << "source: (" << sourceVertex.x << ", " << sourceVertex.y << ") / target: (" << targetVertex.x << ", " << targetVertex.y << ")" << endl;
			cout << "deltaX: " << deltaX << endl;
			cout << "deltaY: " << deltaY << endl;
			cout << "slope: " << slope << endl;
			*/
	}

	~EdgeSlopeConstraint() {
		
	}

};

#endif