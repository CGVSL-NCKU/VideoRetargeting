#ifndef CUDA_COMMON_H
#define CUDA_COMMON_H

#include <cuda_runtime.h>
#include <cutil_inline.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

#ifndef DEGREEOF
#define DEGREEOF(a) (((float)a*(float)180.0)/(float)M_PI)
#endif

#ifndef RADIANOF
#define RADIANOF(a) (((float)a*(float)M_PI)/(float)180.0)
#endif

////////////////////////////////////////////////////////////////////////////////
// Common definitions
////////////////////////////////////////////////////////////////////////////////
typedef unsigned int uint;
typedef unsigned char uchar ;

struct FlowInfo
{
	int frameTime ;
	int distance ;
} ;

struct HumanDetectInfo
{
	float x1 , x2 ;
	float y1 , y2 ;
} ;

struct VideoInfo
{
	int width ;
	int height ;
	int frameNum ;
	int stepFrame ;
	float maxLen ;
} ;

// extern "C" void initHistogram256(void);
// extern "C" void closeHistogram256(void);
// extern "C" void histogram256( uint *cutShift , void *d_DataR , void *d_DataG , void *d_DataB , uint frameShift , uint byteCount ) ;
extern "C" void initEntropyFlow( VideoInfo videoInfoData ) ;
extern "C" void closeEntropyFlow(void) ;
extern "C" void cudaEntropyFlow( float *colAvgFlow , float *colEntropy , float *pixelFlowX , float *pixelFlowY , VideoInfo videoInfoData ) ; 

#endif
