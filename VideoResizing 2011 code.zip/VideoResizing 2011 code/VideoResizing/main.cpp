#include "main.h"

void manager_image::OpenGLinitial()
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);	// Set Texture Max Filter
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);	// Set Texture Min Filter

	GLfloat  ambientLight[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat  diffuseLight[] = { 0.8f, 0.5f, 0.0f, 1.0f };
	GLfloat  specular[] = { 0.6f, 0.6f, 0.6f, 1.0f};
	GLfloat  Lposition[] = {0.0f, 10.0f, 0.0f , 1.0f};

	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	glLightfv(GL_LIGHT0,GL_AMBIENT,ambientLight);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuseLight);
	glLightfv(GL_LIGHT0,GL_SPECULAR,specular);
	glLightfv(GL_LIGHT0,GL_POSITION,Lposition);
	glEnable(GL_LIGHT0);

	glClearColor(1.0f , 1.0f , 1.0f , 1.0f);

}

void manager_image::PanelResize(int width , int height)
{
	if (height==0)										// Prevent A Divide By Zero By
		height=1;										// Making Height Equal One

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	gluOrtho2D(0, width, height, 0);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();


}

void manager_image::CreateQuadMesh()
{
	//  �p��GridSize�PQuadSize
	xGridSize = Image_width / gridRes;
	yGridSize = Image_height / gridRes;
	xQuadSize = (float)Image_width / (float)xGridSize;
	yQuadSize = (float)Image_height / (float)yGridSize;

	// vertex list
	vertexList.resize((xGridSize + 1) * (yGridSize + 1));

	//  �x�s�C�@�ӳ��I���y��
	for (int j = 0 ; j < xGridSize + 1 ; j++)
	{
		for (int k = 0 ; k < yGridSize + 1 ; k++)
		{
			int	vIdx = k * (xGridSize + 1) + j;
			vector2 pos((float)j * xQuadSize , (float)k * yQuadSize);

			vertexList[vIdx] = pos;
		}
	}

	vertexNum = vertexList.size();

	//  �O���Oboundary�����Iid
	for(int i = 0 ; i < vertexNum ; i++)
	{
		if(vertexList[i].x == 0 || vertexList[i].x == Image_width)  x_boundary.push_back(i);
		if(vertexList[i].y == 0 || vertexList[i].y == Image_height) y_boundary.push_back(i);
	}
	
	//  �N���I�y�нƻs���L�x�s�y�Ъ��}�C
	referenceList = vertexList;

	//  �p��k�U���������Iid
	rbIdx = (xGridSize + 1) * (yGridSize + 1) - 1 ;
	
}

vector3 manager_image::GrayToColor(float gray)
{
	// gray���Ƕ��Aresult�m��
	float weight = gray;

	// result.x��R�Aresult.y��G�Aresult.z��B
	vector3 result(0.0f , 0.0f , 0.0f);

	if (weight > 1.0f)		return vector3(1.0f , 0.0f , 0.0f);
	if (weight < 0.0f)		return vector3(0.0f , 0.0f , 1.0f);

	if (weight < 0.33333f)
	{
		result.z = 1.0f - weight * 3.0f;
		result.y = weight * 3.0f;
	}
	else if (weight < 0.66666f)
	{
		result.x = (weight - 0.33333f) * 3.0f;
		result.y = 1.0f;
	}
	else
	{
		result.x = 1.0f;
		result.y = 1.0f - (weight - 0.66666f) * 3.0f;
	}

	return result;
}

void manager_image::saliencyMeasure(bool m_saliency , vector<vector4> faceList)
{
    // Create memory�ASaliencyMap��pixel level��saliency
	saliencyMap = new float[Image_width * Image_height];

	// Create memory�AfaceflexibleList��quad level��saliency
	faceflexibleList.clear();
	int face_size = faceList.size();
	faceflexibleList.resize(face_size);

	for (int i = 0 ; i < face_size ; i++)
		faceflexibleList[i] = 0.0f;

	//  cuda initial
	cudaInitSaliencyMap(Image_width , Image_height);

	// pixel saliency
	cudaContrast((uchar *)Image->imageData , saliencyMap);

	//  �p��C�@��quad�ֿn��saliency
	for (int j = 0 ; j < Image_width ; j++)
	{
		for (int k = 0 ; k < Image_height ; k++)
		{
			int xIdx = j / xQuadSize;
			int yIdx = k / yQuadSize;
			int qIdx = yIdx * xGridSize + xIdx;

			faceflexibleList[qIdx] += saliencyMap[k * Image_width + j];
		}
	}

	//  ��pixel level���̤j��
	float max_differ = 10000.0;
	for(int i = 0 ; i < Image_width * Image_height ; ++i)
	{
		if(saliencyMap[i] > max_differ)  saliencyMap[i] = max_differ;
	}

    // ��C�@��pixel�@normalize
	for(int i = 0 ; i < Image_width * Image_height ; ++i)
	{
		saliencyMap[i] /= max_differ;
		saliencyMap[i] = saliencyMap[i]*0.9 + 0.1;
	}

	// �P�_�n���ndelete memory
	if(!m_saliency) delete [] saliencyMap;
	cudaDinitSaliencyMap();

	// normalize face saliency
	float maxSaliency = 0.0f;

	// ��quad�̤j��saliency
	for (int i = 0 ; i < face_size ; i++)
		if (maxSaliency < faceflexibleList[i])
			maxSaliency = faceflexibleList[i];

	// ��C�@��quad�@normalize
	for (int i = 0 ; i < face_size ; i++)
	{
		faceflexibleList[i] /= maxSaliency;
		faceflexibleList[i] = faceflexibleList[i] * 0.9f + 0.1f ;
	}

}

void manager_image::RGB2Lab(vector3 &color)
{
	matrix33 m;
	m.col[0].set(0.412453f , 0.212671f , 0.019334f);
	m.col[1].set(0.357580f , 0.715160f , 0.119193f);
	m.col[2].set(0.180423f , 0.072169f , 0.950227f);

	vector3 xyz = m * (color / 255.0f);

	xyz.x /= 0.950456f;
	xyz.z /= 1.088754f;

	if (xyz.y > 0.008856f)
		color.x = 116 * pow(xyz.y , 0.333333f) - 16;
	else
		color.x = 903.3f * xyz.y;

	vector3 fxyz = xyz;

	for (int i = 0 ; i < 3 ; i++)
	{
		if (fxyz[i] > 0.008856f)
			fxyz[i] = pow(fxyz[i] , 0.333333f);
		else
			fxyz[i] = 7.787f * fxyz[i] + 16.0f / 116.0f;
	}

	color.y = 500.0f * (fxyz.x - fxyz.y) + 128.0f;
	color.z = 200.0f * (fxyz.y - fxyz.z) + 128.0f;
}

void manager_image::saliencyMeasureCanny(bool m_saliency , vector<vector4> faceList)
{
	// Create memory�ASaliencyMap��pixel level��saliency
	saliencyMap = new float[Image_width * Image_height];

	// Create memory�AfaceflexibleList��quad level��saliency
	faceflexibleList.clear();
	int face_size = faceList.size();
	faceflexibleList.resize(face_size);

	for (int i = 0 ; i < face_size ; i++)
		faceflexibleList[i] = 0.0f;

	int step = 1, count = 0;
	IplImage *hiarImg , *hiarSmooth, *hiarMap , *srcMap;

	srcMap = cvCreateImage(cvSize(Image_width , Image_height) , IPL_DEPTH_8U , 1);
	

	//vector<float> salientMap;

	//salientMap.clear();
	//salientMap.resize(Image_width * Image_height);

	for (int i = 0 ; i < Image_width * Image_height ; i++)
		saliencyMap[i] = 0.0f;

	while (true)
	{
		int w = Image_width / step;
		int h = Image_height / step;

		if (w * h < 1500)	break;
		if(count == 1) break;

		hiarMap = cvCreateImage(cvSize(w , h) , IPL_DEPTH_8U , 1);
		hiarImg = cvCreateImage(cvSize(w , h) , Image->depth , Image->nChannels);
		hiarSmooth = cvCreateImage(cvSize(w , h) , Image->depth , Image->nChannels);

		cvResize(Image , hiarImg , CV_INTER_CUBIC);
		cvSmooth(hiarImg , hiarSmooth , CV_MEDIAN , 15 , 0);

		vector<vector3> img32;
		img32.resize(w * h);

		for (int i = 0 ; i < w * h ; i++)
		{
			img32[i].set(	(float)(unsigned char)hiarSmooth->imageData[3 * i] , 
				(float)(unsigned char)hiarSmooth->imageData[3 * i + 1] , 
				(float)(unsigned char)hiarSmooth->imageData[3 * i + 2]);

			RGB2Lab(img32[i]);
		}

		// gradient computation for the color image
		for (int i = 0 ; i < w ; i++)
		{
			int idx1 = i;
			int idx2 = w * (h - 1) + i;

			hiarMap->imageData[idx1] = 0;
			hiarMap->imageData[idx2] = 0;
		}

		for (int i = 0 ; i < h ; i++)
		{
			int idx1 = w * i;
			int idx2 = w * i + w - 1;

			hiarMap->imageData[idx1] = 0;
			hiarMap->imageData[idx2] = 0;
		}

		for (int i = 1 ; i < w - 1 ; i++)
			for (int j = 1 ; j < h - 1 ; j++)
			{
				int idx = j * w + i;
				vector3 gx =	2.0f * img32[idx + 1] + img32[idx - w + 1] + img32[idx + w + 1] - 
					2.0f * img32[idx - 1] - img32[idx - w - 1] - img32[idx + w - 1];

				vector3 gy =	2.0f * img32[idx - w] + img32[idx - w - 1] + img32[idx - w + 1] - 
					2.0f * img32[idx + w] - img32[idx + w - 1] - img32[idx + w + 1];

				float g = (gx.length() + gy.length());

				if (g > 255.0f)		g = 255.0f;
				hiarMap->imageData[idx] = (char)g;
			}

			cvResize(hiarMap , srcMap , CV_INTER_CUBIC);

			for (int i = 0 ; i < Image_width * Image_height ; i++)
				saliencyMap[i] += ((float)(unsigned char)srcMap->imageData[i] / 255.0f);

			count += 1;
			step *= 2;
			img32.clear();

			cvReleaseImage(&hiarImg);
			cvReleaseImage(&hiarMap);
			cvReleaseImage(&hiarSmooth);
	}

	cvReleaseImage(&srcMap);

// 	float max = -100.0f;
// 
	for (int i = 0 ; i < Image_width * Image_height ; i++)
	{
		saliencyMap[i] /= (float)count;

// 		if (max < saliencyMap[i])	
// 			max = saliencyMap[i];
	}

	//  �p��C�@��quad�ֿn��saliency
	for (int j = 0 ; j < Image_width ; j++)
	{
		for (int k = 0 ; k < Image_height ; k++)
		{
			int xIdx = j / xQuadSize;
			int yIdx = k / yQuadSize;
			int qIdx = yIdx * xGridSize + xIdx;

			faceflexibleList[qIdx] += saliencyMap[k * Image_width + j];
		}
	}

	//  ��pixel level���̤j��
	float max_differ = -10000.0;
	for(int i = 0 ; i < Image_width * Image_height ; ++i)
	{
		if(saliencyMap[i] > max_differ)  max_differ = saliencyMap[i];
	}

	// ��C�@��pixel�@normalize
	for(int i = 0 ; i < Image_width * Image_height ; ++i)
	{
		saliencyMap[i] /= max_differ;
		saliencyMap[i] = saliencyMap[i]*0.9 + 0.1;
	}

	// �P�_�n���ndelete memory
	if(!m_saliency) delete [] saliencyMap;

	// normalize face saliency
	float maxSaliency = 0.0f;

	// ��quad�̤j��saliency
	for (int i = 0 ; i < face_size ; i++)
		if (maxSaliency < faceflexibleList[i])
			maxSaliency = faceflexibleList[i];

	// ��C�@��quad�@normalize
	for (int i = 0 ; i < face_size ; i++)
	{
		faceflexibleList[i] /= maxSaliency;
		faceflexibleList[i] = faceflexibleList[i] * 0.9f + 0.1f ;
	}

// 	for (int i = 0 ; i < Image_width * Image_height ; i++)
// 	{
// 		salientMap[i] /= max;
// 
// 		if (salientMap[i] > 1.0f)
// 			salientMap[i] = 1.0f;
// 
// 		unsigned char ch = (unsigned char)(salientMap[i] * 255.0f);
// 
// 		cannyImg->imageData[3 * i] = ch;
// 		cannyImg->imageData[3 * i + 1] = ch;
// 		cannyImg->imageData[3 * i + 2] = ch;
// 	}

}

void manager_image::facedetection()
{
	// face detect��database ���|
	string cascadeName =
		"haarcascades/haarcascade_frontalface_alt.xml";

	// Ūdatabase
	CvHaarClassifierCascade* cascade = (CvHaarClassifierCascade*)cvLoad( cascadeName.c_str()) ;

	IplImage *frame = Image;

	IplImage *frameCopy = cvCreateImage( cvSize( frame->width , frame->height ) , 8 , 3 ) ;

	// Ū��l�Ϥ�
	if( frame->origin == IPL_ORIGIN_TL  )
		cvCopy( frame, frameCopy, NULL ) ;
	else
		cvFlip( frame , frameCopy, NULL ) ;

	CvMemStorage* storage = cvCreateMemStorage(0);
	CvSeq* faces;
	float scale = 1.2;

	//cvClearMemStorage( storage ) ;


	CvSize ImageSize1 = cvSize(frameCopy->width,frameCopy->height);
	IplImage* gray = cvCreateImage(ImageSize1,IPL_DEPTH_8U,1); 

	IplImage* small_img = cvCreateImage( cvSize( cvRound (frameCopy->width/scale) , cvRound (frameCopy->height/scale) ) , 8 , 1 ) ;

	// �Ϥ���Ƕ�
	for(int m = 0 ; m < frameCopy->width ; ++m)
	{
		for(int n = 0 ; n < frameCopy->height ; ++n)
		{
			uchar B = frame->imageData[n * frameCopy->widthStep + 3*m];
			uchar G = frame->imageData[n * frameCopy->widthStep + 3*m+1];
			uchar R = frame->imageData[n * frameCopy->widthStep + 3*m+2];

			gray->imageData[n * gray->widthStep + m] = (R + G + B) / 3 ;
		}
	}

	cvResize( gray, small_img, CV_INTER_LINEAR ) ;
	cvEqualizeHist( small_img, small_img);

	// face detect
	faces = cvHaarDetectObjects( small_img, cascade, storage, scale, 3, 2,cvSize(50,50));

	// �x�sface detect�����G
	for(int j = 0; j < faces->total; ++j)
	{

		CvRect face_rect = *(CvRect*)cvGetSeqElem( faces, j );

		vector4 temp(face_rect.x*scale,face_rect.y*scale,(face_rect.x+face_rect.width)*scale,(face_rect.y+face_rect.height)*scale);

		face_detect.push_back(temp);
	}

	cvReleaseHaarClassifierCascade(&cascade);
	cvReleaseImage(&small_img);
	cvReleaseImage(&gray);
	cvReleaseImage(&frameCopy);
	cvReleaseMemStorage( &storage );

}

void manager_image::SimilarityCoeff(const vector<vector4> &Ap, float **coeff)
{
	// AP ����J���x�}
	matrix44 ApTAp;

	// ATA
	for (int i = 0 ; i < 4 ; ++i)
	{
		for (int j = 0 ; j < 4 ; ++j)
		{
			ApTAp[i][j] = 0.0f;

			for (int m = 0 ; m < 8 ; ++m)
				ApTAp[i][j] += Ap[m][i] * Ap[m][j];
		}
	}

	// ATA^-1
	ApTAp.invert();

	// (ATA^-1)^T
	ApTAp.transpose();

	vector<vector4> mx;
	mx.clear();
	mx.resize(8);

	// A*(ATA^-1)^T
	for (int i = 0 ; i < 8 ; ++i)
		mx[i] = ApTAp * Ap[i];

	for (int i = 0 ; i < 8 ; ++i)
	{
		for (int j = 0 ; j < 8 ; ++j)
		{
			coeff[i][j] = 0.0f;

			for (int m = 0 ; m < 4 ; ++m)
				coeff[i][j] += mx[i][m] * Ap[j][m];
		}
	}

	// A*(ATA^-1)^T - I
	for (int i = 0 ; i < 8 ; ++i)
		coeff[i][i] -= 1.0f;
}

void manager_image::Calculatecoeff(vector<vector4> faceList)
{
	unsigned int faceNum = faceList.size();

	// Create Memory
	coeff = new float*[8];
	for (int j = 0 ; j < 8 ; ++j)
	{
		coeff[j] = new float[8];
	}


	vector<vector4> Ap;

	Ap.clear();
	Ap.resize(8);

    // ��x�}
	int vList[4] = {faceList[0].x,faceList[0].y,faceList[0].z,faceList[0].w};
	// coeff only compute for first iteration
	for (int j = 0 ; j < 4 ; ++j)
	{
		Ap[2 * j + 0].x = referenceList[vList[j]].x;
		Ap[2 * j + 0].y = -referenceList[vList[j]].y;
		Ap[2 * j + 0].z = 1.0f;
		Ap[2 * j + 0].w = 0.0f;

		Ap[2 * j + 1].x = referenceList[vList[j]].y;
		Ap[2 * j + 1].y = referenceList[vList[j]].x;
		Ap[2 * j + 1].z = 0.0f;
		Ap[2 * j + 1].w = 1.0f;
	}

	// ��Y��
	SimilarityCoeff(Ap, coeff);  

	for (int i = 0 ; i < 8 ; ++i)
		for (int j = 0 ; j < 8 ; ++j)
			if (fabs(coeff[i][j]) < 0.00001f)	coeff[i][j] = 0.0f;
}

void manager_image::PatchDeformation(vector2 resolution , double avg_move , vector<vector4> faceList)
{

	 unsigned int xBoundaryNum = x_boundary.size();
	 unsigned int yBoundaryNum = y_boundary.size();
	 unsigned int faceNum = faceList.size();

 	 vertexNum = vertexList.size();

	 int edge_count = xGridSize * (yGridSize + 1) + (xGridSize + 1) * yGridSize;

	 const int cols = 2 * vertexNum;

	 const int rows = 8*faceNum + xBoundaryNum + yBoundaryNum  +  2*edge_count;
	
	 float *B = new float[rows];
	 float *x = new float[cols];

	 int rowIdx = 0;

	 float weight_scale = 1.0;
	 float edgeWeight = 1.0f;
	 float critical_weight = 0.03;

	 if(avg_move == 1.0)  critical_weight = 100.0;
	 else                 ;//critical_weight = avg_move;


	 if(!solver.IsTheSameSize(rows,cols))
	 {
		 solver.ResetSolver(rows, cols);

	     // -------------------------------------- set system matrix -------------------------------------
	     // aspect ratio

		 rowIdx = 0;

		 for (unsigned int i = 0 ; i < faceNum ; ++i)
		 {
			 int vList[4] = {faceList[i].x,faceList[i].y,faceList[i].z,faceList[i].w};
			 float weight = weight_scale*faceflexibleList[i];

			 for (int j = 0 ; j < 8 ; ++j)
			 {
				 if (coeff[j][0] != 0.0f)	solver.AddSysElement(rowIdx, vList[0],				weight * coeff[j][0]);
				 if (coeff[j][1] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[0],	weight * coeff[j][1]);
				 if (coeff[j][2] != 0.0f)	solver.AddSysElement(rowIdx, vList[1],				weight * coeff[j][2]);
				 if (coeff[j][3] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[1],	weight * coeff[j][3]);
				 if (coeff[j][4] != 0.0f)	solver.AddSysElement(rowIdx, vList[2],				weight * coeff[j][4]);
				 if (coeff[j][5] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[2],	weight * coeff[j][5]);
				 if (coeff[j][6] != 0.0f)	solver.AddSysElement(rowIdx, vList[3],				weight * coeff[j][6]);
				 if (coeff[j][7] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[3],	weight * coeff[j][7]);
				 ++rowIdx;
			 }
		 }

		 /// Boundary Constraint ( #row: xBoundaryNum + yBoundaryNum )
		 for (unsigned int i = 0 ; i < xBoundaryNum ; ++i) {
			
			 solver.AddSysElement(rowIdx++ , x_boundary[i] , critical_weight);

		 }
		 for (unsigned int i = 0 ; i < yBoundaryNum ; ++i) {
			 float weight = 100.0f;
			 solver.AddSysElement(rowIdx++ , vertexNum + y_boundary[i] , weight);
		 }	 

		 // edge constraints
		 // vertical
		 for (int j = 0 ; j < xGridSize  + 1; ++j)
		 {
			 for (int k = 0 ; k < yGridSize ; ++k)
			 {
				 // (j , k) - (j , k + 1)
				 int v1 = k      * (xGridSize + 1) + j;
				 int v2 = (k+1)  * (xGridSize + 1) + j;

				 solver.AddSysElement(rowIdx , v1 , edgeWeight);
				 solver.AddSysElement(rowIdx++ , v2 , -edgeWeight);

				 solver.AddSysElement(rowIdx, vertexNum + v1, -edgeWeight);			
				 solver.AddSysElement(rowIdx++, vertexNum + v2, edgeWeight);
			 }
		 }
		 // horizontal
		 for (int j = 0 ; j < xGridSize ; ++j)
		 {
			 for (int k = 0 ; k < yGridSize + 1 ; ++k)
				{
					// (j , k) - (j + 1 , k)
					int v1 = k * (xGridSize + 1) + j;
					int v2 = k * (xGridSize + 1) + j+1;

					solver.AddSysElement(rowIdx , vertexNum + v1 , edgeWeight);
					solver.AddSysElement(rowIdx++ , vertexNum + v2 , -edgeWeight);

					solver.AddSysElement(rowIdx, v1, -edgeWeight);	                        
					solver.AddSysElement(rowIdx++, v2, edgeWeight);
				}
		 }

	 }

	 // ------------------------------------ set right hand size matrix --------------------------------
	 rowIdx = 0;

	 // aspect ratio

	 for (unsigned int i = 0 ; i < 8*faceNum ; ++i)
	 {
		 B[rowIdx++] = 0.0f;
	 }
	  
	 /// Boundary Constraint
	 for (unsigned int i = 0 ; i < xBoundaryNum ; ++i)	// x
	 {
		 if(referenceList[x_boundary[i]].x == referenceList[0].x)
			 B[rowIdx++] = critical_weight * 0.0f;
		 else 
			 B[rowIdx++] = critical_weight * resolution.x;

		 
	 }
	 for (unsigned int i = 0 ; i < yBoundaryNum ; ++i)	// y
	 {
		 float weight = 100.0f;
		 if(referenceList[y_boundary[i]].y == referenceList[0].y)
			 B[rowIdx++] = weight * 0.0f;
		 else
			 B[rowIdx++] = weight * resolution.y;
	 }
     
	 // edge constraints
	 // vertical
	 for (int j = 0 ; j < xGridSize  + 1; ++j)
	 {
		 for (int k = 0 ; k < yGridSize ; ++k)
		 {
			 // (j , k) - (j , k + 1)
			 int v1 = k      * (xGridSize + 1) + j;
			 int v2 = (k+1)  * (xGridSize + 1) + j;

			 B[rowIdx++] = 0;
			 B[rowIdx++] = edgeWeight * (vertexList[v2].y - vertexList[v1].y);
		 }
	 }
	 // horizontal
	 for (int j = 0 ; j < xGridSize ; ++j)
	 {
		 for (int k = 0 ; k < yGridSize + 1 ; ++k)
		 {
			 // (j , k) - (j + 1 , k)
			 int v1 = k * (xGridSize + 1) + j;
			 int v2 = k * (xGridSize + 1) + j+1;

			 B[rowIdx++] = 0;
			 B[rowIdx++] = edgeWeight * (vertexList[v2].x - vertexList[v1].x);
		 }
	 }

	// Set right hand size matrix
	solver.SetRightHandSideMatrix(B);
    
    // ------------------------------------------ initial guess ---------------------------------------
	rowIdx = 0;

	for (int i = 0 ; i < vertexNum ; ++i)
	{
        x[rowIdx] =  vertexList[i].x;
		x[vertexNum + rowIdx] = vertexList[i].y;
		rowIdx++;
	}

	solver.SetInitialGuess(x);

	// ---------------------------------------------- solve -------------------------------------------
	solver.solve();

	// �N���G�s�bcomparison
	comparison.clear();
	rowIdx = 0;
	for(int i = 0 ; i < vertexNum ; ++i)
	{
         vector2 pos(solver.GetSolution(rowIdx) , solver.GetSolution(vertexNum + rowIdx));
		 comparison.push_back(pos);

		 rowIdx++;
	}

	delete [] B;
	delete [] x;

}

void manager_image::RefineDeformation(vector<vector4> faceList)
{
	unsigned int xBoundaryNum = x_boundary.size();
	unsigned int yBoundaryNum = y_boundary.size();
	unsigned int faceNum = faceList.size();

	vertexNum = vertexList.size();

	int edge_count = xGridSize * (yGridSize +1) + (xGridSize+1) * yGridSize;

	int trajectory_count = trajectory.size();

	const int cols = 2 * vertexNum;

	// faceNum                       : conformal energy
	// xBoundaryNum and yBoundaryNum : boundary constraint
	// trajectory_count              : trajectory constraint
	const int rows = 8*faceNum + xBoundaryNum + yBoundaryNum +  2 * trajectory_count + 2*edge_count;

	// initial
	float *B = new float[rows];
	float *x = new float[cols];

	int rowIdx = 0;

	float conformal_weight = 1.0;
	float edgeWeight       = 10.0f;
	float trajectoryWeight = 1.0;
	

	if(!solver.IsTheSameSize(rows,cols))
	{
		 solver.ResetSolver(rows, cols);

		 //--------------------------------------------------------------------------------------

		 // conformal energy
		 rowIdx = 0;

		 for (unsigned int i = 0 ; i < faceNum ; ++i)
		 {
			 int vList[4] = {faceList[i].x,faceList[i].y,faceList[i].z,faceList[i].w};
			 float weight = conformal_weight*faceflexibleList[i];

			 for (int j = 0 ; j < 8 ; ++j)
			 {
				 if (coeff[j][0] != 0.0f)	solver.AddSysElement(rowIdx, vList[0],				weight * coeff[j][0]);
				 if (coeff[j][1] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[0],	weight * coeff[j][1]);
				 if (coeff[j][2] != 0.0f)	solver.AddSysElement(rowIdx, vList[1],				weight * coeff[j][2]);
				 if (coeff[j][3] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[1],	weight * coeff[j][3]);
				 if (coeff[j][4] != 0.0f)	solver.AddSysElement(rowIdx, vList[2],				weight * coeff[j][4]);
				 if (coeff[j][5] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[2],	weight * coeff[j][5]);
				 if (coeff[j][6] != 0.0f)	solver.AddSysElement(rowIdx, vList[3],				weight * coeff[j][6]);
				 if (coeff[j][7] != 0.0f)	solver.AddSysElement(rowIdx, vertexNum + vList[3],	weight * coeff[j][7]);
				 ++rowIdx;
			 }

		 }

		 //  x boundary constraint
		 for (unsigned int i = 0 ; i < xBoundaryNum ; ++i) {
			 float weight = 100.0f;
			 solver.AddSysElement(rowIdx++ , x_boundary[i] , weight);
		 }

		 //  y boundary constraint
		 for (unsigned int i = 0 ; i < yBoundaryNum ; ++i) {
			 float weight = 100.0f;
			 solver.AddSysElement(rowIdx++ , vertexNum + y_boundary[i] , weight);
		 }	 

		 // edge constraints
		 // vertical
		 for (int j = 0 ; j < xGridSize +1; j++)
		 {
			 for (int k = 0 ; k < yGridSize ; k++)
			 {
				 // (j , k) - (j , k + 1)
				 int v1 = k      * (xGridSize + 1) + j;
				 int v2 = (k+1)  * (xGridSize + 1) + j;

				 solver.AddSysElement(rowIdx , v1 , edgeWeight);
				 solver.AddSysElement(rowIdx++ , v2 , -edgeWeight);

				 solver.AddSysElement(rowIdx, vertexNum + v1, -edgeWeight);			
				 solver.AddSysElement(rowIdx++, vertexNum + v2, edgeWeight);
			 }
		 }
		 // horizontal
		 for (int j = 0 ; j < xGridSize ; j++)
		 {
			 for (int k = 0 ; k < yGridSize +1; k++)
			 {
					// (j , k) - (j + 1 , k)
					int v1 = k * (xGridSize + 1) + j;
					int v2 = k * (xGridSize + 1) + j+1;

					solver.AddSysElement(rowIdx , vertexNum + v1 , edgeWeight);
					solver.AddSysElement(rowIdx++ , vertexNum + v2 , -edgeWeight);

					solver.AddSysElement(rowIdx, v1, -edgeWeight);	                        
					solver.AddSysElement(rowIdx++, v2, edgeWeight);
			 }
		 }


		 // trajectory constraint
		 // trajectory_face�����o�@��trajectory�b�o�@��frame�O�_�s�b
		 // trajectory_face�ȵ��� -1 �A�N�����s�b
		 // ��L�ȫh�N���o��trajectory�b�o��frame�����@��face

		 //int face_size = trajectory_face.size();
		 for(int i = 0 ; i < trajectory_count ; i++)
		 {
			     vector2 v1 , v2 , v3 , v4 , p;
                 p       = trajectory[i];

			     int xIdx = p.x / xQuadSize;
			     int yIdx = p.y / yQuadSize;
			     int face = yIdx * xGridSize + xIdx;
				 
				 // face�W�����Iid
				 int vList[4] = { faceList[face].x , faceList[face].y , faceList[face].z , faceList[face].w};   

				 float weight = trajectoryWeight ;

				 if(trajectory_weight[i] == 0) weight = 0.0;

				 // v1 v2 v3 ��lframe�����I�y�� p�O��l�y�񪺮y��
				                                                                      
				 v1      = referenceList[vList[0]];
				 v2      = referenceList[vList[1]];
				 v3      = referenceList[vList[2]];
				 v4      = referenceList[vList[3]];
				 

				 double r1_x = (v2.x - p.x) / (v2.x - v1.x); 
				 double r1_y = (v3.y - p.y) / (v3.y - v1.y); 

				 solver.AddSysElement(rowIdx,     vList[0], weight*r1_x*r1_y);
				 solver.AddSysElement(rowIdx,     vList[1], weight*(1-r1_x)*r1_y);
				 solver.AddSysElement(rowIdx,     vList[2], weight*(1-r1_x)*(1-r1_y));
				 solver.AddSysElement(rowIdx++,   vList[3], weight*r1_x*(1-r1_y));
				 solver.AddSysElement(rowIdx,     vertexNum + vList[0], weight*r1_x*r1_y);
				 solver.AddSysElement(rowIdx,     vertexNum + vList[1], weight*(1-r1_x)*r1_y);
				 solver.AddSysElement(rowIdx,     vertexNum + vList[2], weight*(1-r1_x)*(1-r1_y));
				 solver.AddSysElement(rowIdx++,   vertexNum + vList[3], weight*r1_x*(1-r1_y));
		 }

		 

	 }

	 
	 // ------------------------------------ set right hand size matrix --------------------------------

	 //--------------------------------------------------------------------------------
	 rowIdx = 0;

	 // conformal energy
	 for (unsigned int i = 0 ; i < 8*faceNum ; ++i)
	 {
		 B[rowIdx++] = 0.0f;
	 }

	 //  x boundary constraint
	 for (unsigned int i = 0 ; i < xBoundaryNum ; ++i)	// x
	 {
		 float weight = 100.0f;
		 if(referenceList[x_boundary[i]].x == referenceList[0].x)
			 B[rowIdx++] = weight * 0.0f;
		 else
			 B[rowIdx++] = weight * vertexList[rbIdx].x;
	 }

	 //  y boundary constraint
	 for (unsigned int i = 0 ; i < yBoundaryNum ; ++i)	// y
	 {
		 float weight = 100.0f;
		 if(referenceList[y_boundary[i]].y == referenceList[0].y)
			 B[rowIdx++] = weight * 0.0f;
		 else
			 B[rowIdx++] = weight * vertexList[rbIdx].y;
	 }

	 // edge constraints
	 // vertical
	 for (int j = 0 ; j < xGridSize +1; j++)
	 {
		 for (int k = 0 ; k < yGridSize ; k++)
		 {
			 // (j , k) - (j , k + 1)
			 int v1 = k      * (xGridSize + 1) + j;
			 int v2 = (k+1)  * (xGridSize + 1) + j;

			 B[rowIdx++] = 0;

			 B[rowIdx++] = edgeWeight * (vertexList[v2].y - vertexList[v1].y);
		 }
	 }
	 // horizontal
	 for (int j = 0 ; j < xGridSize ; j++)
	 {
		 for (int k = 0 ; k < yGridSize +1; k++)
		 {
			 // (j , k) - (j + 1 , k)
			 int v1 = k * (xGridSize + 1) + j;
			 int v2 = k * (xGridSize + 1) + j+1;

			 B[rowIdx++] = 0;

			 B[rowIdx++] = edgeWeight * (vertexList[v2].x - vertexList[v1].x);
		 }
	 }

	 // trajectory constraint
	 // trajectory_face�����o�@��trajectory�b�o�@��frame�O�_�s�b
	 // trajectory_face�ȵ��� -1 �A�N�����s�b
	 // trajectory_adjust����X��trajectory�y��
	 //trajectory_face_size = trajectory_face.size();
	 for(int i = 0 ; i < trajectory_count ; i++)
	 {
			 float weight = trajectoryWeight ;

			 if(trajectory_weight[i] == 0) weight = 0.0;
			
			 B[rowIdx++] = weight*trajectory_adjust[i].x;
			 B[rowIdx++] = weight*trajectory_adjust[i].y;
	 }

	 // Set right hand size matrix
	 solver.SetRightHandSideMatrix(B);

	 // ------------------------------------------ initial guess ---------------------------------------
	 rowIdx = 0;

	 for (int i = 0 ; i < vertexNum ; i++)
	 {
		 x[rowIdx] =  vertexList[i].x;
		 x[vertexNum + rowIdx] = vertexList[i].y;
		 rowIdx++;
	 }

	 solver.SetInitialGuess(x);

	 // ---------------------------------------------- solve -------------------------------------------
	 solver.solve();

	 comparison.clear();
	 
	 rowIdx = 0;
	 for(int i = 0 ; i < vertexNum ; i++)
	 {
		 vector2 pos(solver.GetSolution(rowIdx) , solver.GetSolution(vertexNum + rowIdx));
		 comparison.push_back(pos);

		 rowIdx++;
	 }

	 delete [] B;
	 delete [] x;
}

void manager_video::LoadVideo(string filename)
{
	 m_capture           = NULL;

	 m_capture	= cvCaptureFromFile( filename.c_str() );
	 frameNum	= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_COUNT ) ;
	 vWidth		= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_WIDTH ) ;
	 vHeight	= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_HEIGHT ) ;
	 vFPS		= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FPS ) ;

	 if (frameNum == 0 || vWidth == 0 || vHeight == 0 || vFPS == 0)
	 {
		cout << "file loading failed!" << endl;
	 }
	 else
	 {
		cout << "------------------- video information ---------------------" << endl;
		cout << "width = " << vWidth << " , height = " << vHeight << " , fps = " << vFPS << " , frames = " << frameNum << endl;

		trajectory.clear();
		key_frame.clear();
		leftBound.clear();
		rightBound.clear();

		// ��mesh
		VideoSegmentation(filename);

		// flow setting
		flowlib.cleanup();
		flowlib.setNumImages(2);
		flowlib.setLambda(50);
		flowlib.setGaussTVEpsilon(0.01f);
		flowlib.setNumIter(6);
		flowlib.setNumWarps(5);
		flowlib.setScaleFactor(0.7f);
		flowlib.useDiffusionTensor(true);
		flowlib.setStructureTextureDecomposition("ROF", 0.8f, 10.0f);

		currRes.set(vWidth,vHeight);

		motionpreprocess();

		Render_result = 0;

		
	 }
}

void manager_video::motionpreprocess()
{

	// create memory
	int ImgSize = vWidth * vHeight;

	opticalFlowU = new float[ImgSize*flowSegment];
	opticalFlowV = new float[ImgSize*flowSegment];

	inverseFlowU = new float[ImgSize*flowSegment];
	inverseFlowV = new float[ImgSize*flowSegment];

	colflowMap = new float *[frameNum];
	inv_colflowMap = new float *[frameNum];
	for(int i = 0 ; i < frameNum ; ++i)
	{
		colflowMap[i] = new float[vWidth];
		inv_colflowMap[i] = new float[vWidth];
	}

	leftBound.clear();		leftBound.resize(frameNum);
	rightBound.clear();		rightBound.resize(frameNum);

	for (int i = 0 ; i < frameNum ; i++)
		leftBound[i] = rightBound[i] = vWidth / 2;

	findInitEntropy() ;

	printf("Calculate optical flow and trajectory...... \n");
	double time_1 = clock();

	// �CflowSegment�@�@���U�C�Ʊ��A�w��memory����
	for(int i = 0 ; i < frameNum ; i+= flowSegment)
	{
		printf("%d\n",i);

		// ��flow
		CalculateOpticalFlow(i);

		//CalculateInverseFlow(i);

		// ��y��
		CalculateTrajectory(i);

		// determine col flows for each column
		findColFlows(i);

		// detect foregrounds
		findActiveForegrounds(i);

		// ��saliency
		CalculateMotionSaliency(i);	

	}

	findEntropyBound();

	// detect critical columns
	findCriticalCols();

	int trajectory_size = trajectory.size();

	int length = 0;

	// �O��y��Ѽ�
	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		if(trajectory[i].end_frame == -1) trajectory[i].end_frame = frameNum;
		trajectory[i].length = trajectory[i].end_frame - trajectory[i].start_frame;

		length += trajectory[i].length;
	}

	// ��y��F�~
	FindTrajectoryNeighbor();

	
	printf("%f seconds end\n",(clock()-time_1)/CLK_TCK);

	// �R��optical flow
	delete [] opticalFlowU;
	delete [] opticalFlowV;

 	delete [] colflowMap;
 	delete [] inv_colflowMap;

	delete [] inverseFlowU;
	delete [] inverseFlowV;

}

void manager_video::VideoSegmentation(string filename)
{

	 cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES  , 0 ) ;

	 double time_1 = clock();

	 delete [] image;

	 image = new manager_image[frameNum];

	 // ��mesh��face detection
	 printf("Create Mesh.............. ");
	 for( int i = 0 ; i < frameNum ; i++ )
	 {
		 m_frame	= cvQueryFrame( m_capture );

		 image[i].Image        = m_frame;
		 image[i].Image_width  = vWidth;
		 image[i].Image_height = vHeight;

		 image[i].CreateQuadMesh();
		 if(face_detection) image[i].facedetection();

		 image[i].solver.Create(0,0);
		 
	 }

	 // face list
	 faceList.resize(image[0].xGridSize * image[0].yGridSize);

	 for (int j = 0 ; j < image[0].xGridSize ; j++)
	 {
		 for (int k = 0 ; k < image[0].yGridSize ; k++)
		 {
			 int Idx = k * (image[0].xGridSize + 1) + j;

			 faceList[k * image[0].xGridSize + j].x = Idx;
			 faceList[k * image[0].xGridSize + j].y = Idx + 1;
			 faceList[k * image[0].xGridSize + j].z = Idx + image[0].xGridSize + 2;
			 faceList[k * image[0].xGridSize + j].w = Idx + image[0].xGridSize + 1;

		 }
	 }
	 printf("%f seconds end\n",(clock()-time_1)/CLK_TCK);

}

void manager_video::findInitEntropy()
{
	stepFrame = flowSegment ;

	//		test frame & add frame
	if ( (frameNum-1) % stepFrame == 0 )
		addFrame = 0 ;
	else
		addFrame = stepFrame - (frameNum-1) % stepFrame ; 

	//		max length to GPU , build circle histogram
	float maxLen = 10.0 ;

	//		let GPU know video information
	videoInfoData.frameNum		= frameNum - 1 ;
	videoInfoData.width			= vWidth ;
	videoInfoData.height		= vHeight ;
	videoInfoData.stepFrame		= stepFrame ;
	videoInfoData.maxLen		= maxLen ;

	//		create CPU memory
	m_stepOpticalFlowU = new float [stepFrame*vWidth*vHeight]() ;
	m_stepOpticalFlowV = new float [stepFrame*vWidth*vHeight]() ;
	m_allColEntropy	= new float [ ( frameNum-1 + addFrame )*vWidth ] ;
	m_allColAvgFlow	= new float [ ( frameNum-1 + addFrame )*vWidth ] ;

	//		create GPU memory
	cutilSafeCall( cudaMalloc((void **)&G_stepOptiFlowU		, stepFrame * vWidth * vHeight	* sizeof(float) )) ;
	cutilSafeCall( cudaMalloc((void **)&G_stepOptiFlowV		, stepFrame * vWidth * vHeight	* sizeof(float) )) ;
	cutilSafeCall( cudaMalloc((void **)&G_stepColEntropy	, stepFrame * vWidth			* sizeof(float) )) ;
	cutilSafeCall( cudaMalloc((void **)&G_stepColAvgFlow	, stepFrame * vWidth			* sizeof(float) )) ;

	//		initial GPU
	initEntropyFlow(videoInfoData) ;
}

void manager_video::findEntropyBound()
{
	//		delete GPU memory
	cutilSafeCall( cudaFree(G_stepOptiFlowV) ) ;
	cutilSafeCall( cudaFree(G_stepOptiFlowU) ) ;
	cutilSafeCall( cudaFree(G_stepColEntropy) ) ;
	cutilSafeCall( cudaFree(G_stepColAvgFlow) ) ;
	closeEntropyFlow();

	//		check important column
	int		*checkImpCol ; 

	//		check the same frame 
	int		*checkSameFrame ;
	int		checkSameFrameNum = 0 ;

	m_boundLeft		= new int [frameNum-1]() ;
	m_boundRight	= new int [frameNum-1]() ;
	checkImpCol		= new int [(frameNum-1)*vWidth]() ;
	checkSameFrame	= new int [frameNum-1]() ;


	for ( int fIdx = 0 ; fIdx < frameNum - 1 ; fIdx++ )
	{
		m_boundLeft[fIdx] = vWidth/2 ;
		m_boundRight[fIdx] = vWidth/2 ;
	}

	//		check the same frame by every column flow = 0
	for ( int fIdx = 0 ; fIdx < frameNum - 1 ; fIdx++ )
	{
		int sum = 0 ;
		for ( int w = 0 ; w < vWidth ; w++ )
		{
			if ( m_allColAvgFlow[ fIdx*vWidth + w ] == 0 )		
				sum++ ;	
		}
		if ( sum == vWidth )
		{
			checkSameFrame[fIdx] = 1 ;
			checkSameFrameNum++ ;
		}
	}

	//		boundary threshold = max entropy value * 0.7 
	float everyProb = 1/(float(vHeight)*2) ;
	float entropyThreshold = -everyProb*log(everyProb)/log(2.0)*(float(vHeight)*2) ;

	for ( int fIdx = 0 ; fIdx < frameNum - 1 ; fIdx++ )
	{		
		if ( checkSameFrame[fIdx] == 0 )
		{	
			for ( int w = 0 ; w < vWidth ; w++ )
				if ( m_allColEntropy[ fIdx*vWidth + w ] < entropyThreshold*0.65 )
				{
					checkImpCol[ fIdx*vWidth + w ] = 1 ;	//	�N���O�����n��col	
				}

				for ( int w = 5 ; w < vWidth - 5 ; w++ )
					if ( checkImpCol[ fIdx*vWidth + w ] != 1 && checkImpCol[ fIdx*vWidth + (w+1) ] != 1 && checkImpCol[ fIdx*vWidth + (w+2) ] != 1 )
					{
						m_boundLeft[fIdx] = w ;
						break ;
					}

					for ( int w = vWidth - 6 ; w >= m_boundLeft[fIdx]+1 ; w-- )
						if ( checkImpCol[ fIdx*vWidth + w ] != 1 && checkImpCol[ fIdx*vWidth + (w-1) ] != 1 && checkImpCol[ fIdx*vWidth + (w-2) ] != 1 )
						{
							m_boundRight[fIdx] = w ;
							break ;
						}

						if ( m_boundRight[fIdx] == m_boundLeft[fIdx] /*|| m_boundRight[fIdx] - m_boundLeft[fIdx] < 20*/ )
						{
							m_boundRight[fIdx] = vWidth/2 ;
							m_boundLeft[fIdx] = vWidth/2 ;
						}
		}
	}

	//	frame ���ƮɳB�z
	if ( checkSameFrame[0] == 1 )
	{
		m_boundRight[0] = m_boundRight[1] ;
		m_boundLeft[0] = m_boundLeft[1] ;
	}

	for ( int fIdx = 1 ; fIdx < frameNum - 1 ; fIdx++ )
	{
		if ( checkSameFrame[fIdx] == 1 )
		{
			m_boundRight[fIdx] = m_boundRight[fIdx-1] ;
			m_boundLeft[fIdx] = m_boundLeft[fIdx-1] ;
		}
	}

	//	detect single peak		~~~~^~~~~^~~~~~
	for ( int fIdx = 1 ; fIdx < frameNum - 3 ; fIdx++  )	
	{
		if ( abs(m_boundLeft[fIdx+1] - m_boundLeft[fIdx]) > 20 && abs(m_boundLeft[fIdx] - m_boundLeft[fIdx-1]) > 20 )
			m_boundLeft[fIdx] = m_boundLeft[fIdx-1] ;
		if ( abs(m_boundRight[fIdx+1] - m_boundRight[fIdx]) > 20 && abs(m_boundRight[fIdx] - m_boundRight[fIdx-1]) > 20 )
			m_boundRight[fIdx] = m_boundRight[fIdx-1] ;
	}

	//	detect double peak		~~~~^^~~~~~~~~~
	bool *delLeftPeak , *delRightPeak ;
	delLeftPeak = new bool [frameNum-2]() ;
	delRightPeak = new bool [frameNum-2]() ;

	for ( int fIdx = 0 ; fIdx < frameNum - 2 ; fIdx++  )	
	{
		if ( abs(m_boundLeft[fIdx+1] - m_boundLeft[fIdx]) > 20 )
			delLeftPeak[fIdx] = true ;
		if ( abs(m_boundRight[fIdx+1] -  m_boundRight[fIdx]) > 20 )
			delRightPeak[fIdx] = true ;
	}

	for ( int fIdx = 0 ; fIdx < frameNum - 3 ; fIdx++  )	
	{
		if ( delLeftPeak[fIdx] == true &&  delLeftPeak[fIdx+1] == false &&  delLeftPeak[fIdx+2] == true )
		{
			m_boundLeft[fIdx+1] = m_boundLeft[fIdx] ;
			m_boundLeft[fIdx+2] = m_boundLeft[fIdx] ;
		}
		if ( delRightPeak[fIdx] == true &&  delRightPeak[fIdx+1] == false &&  delRightPeak[fIdx+2] == true )
		{
			m_boundRight[fIdx+1] = m_boundRight[fIdx] ;
			m_boundRight[fIdx+2] = m_boundRight[fIdx] ;
		}
	}

	for ( int fIdx = 0 ; fIdx < frameNum - 1 ; fIdx++  )	
	{
		if ( m_boundLeft[fIdx] < leftBound[fIdx] )	
			leftBound[fIdx] = m_boundLeft[fIdx] ;

		if ( m_boundRight[fIdx] > rightBound[fIdx] )	
			rightBound[fIdx] = m_boundRight[fIdx] ;
	}

	//		delete
	delete [] m_boundRight ;
	delete [] m_boundLeft ;
	delete [] delLeftPeak ;
	delete [] delRightPeak ;
	delete [] m_stepOpticalFlowU ;
	delete [] m_stepOpticalFlowV ;
	delete [] checkImpCol ;
	delete [] m_allColEntropy ;	
	delete [] m_allColAvgFlow ;
	delete [] checkSameFrame ;

	delLeftPeak			= NULL ;
	delRightPeak		= NULL ;
	m_stepOpticalFlowU	= NULL ;
	m_stepOpticalFlowV	= NULL ;
	checkImpCol			= NULL ;
	m_allColEntropy		= NULL ;	
	m_allColAvgFlow		= NULL ;
	checkSameFrame		= NULL ;
}

void manager_video::findCriticalCols()
{
	int end = vWidth - 1;

	vector<int> lbound , rbound;

	lbound.clear();		lbound.resize(frameNum);
	rbound.clear();		rbound.resize(frameNum);

	for (int i = 0 ; i < frameNum ; i++)
	{
		lbound[i] = 0;
		rbound[i] = end;
	}

	for (int i = 0 ; i < frameNum ; i++)
	{
		// ------------ crop left-------------
		// look back
		bool	removed = false;
		float	currPos = lbound[i] + 5;
		int		currIdx = (int)(currPos + 0.5f);

		for (int j = i ; j < frameNum && currIdx >= 0; j++)
		{
			currPos += colflowMap[j][currIdx];
			currIdx = (int)(currPos + 0.5f);

			if (currPos > 15.0f)
			{
				removed = true;
				lbound[i] = end / 2;
				break;
			}
		}

		// look forward
		if (!removed)
		{
			float	currPos = lbound[i] + 5;
			int		currIdx = (int)(currPos + 0.5f) , j = 0;

			for (int j = i ; j >= 0 && currIdx >= 0 ; j--)
			{
				currPos += inv_colflowMap[j][currIdx];
				currIdx = (int)(currPos + 0.5f);

				if (currPos > 15.0f)
				{
					lbound[i] = end / 2;
					break;
				}
			}
		}

		// ------------ crop right -------------
		// look back
		removed = false;
		currPos = rbound[i] - 5;
		currIdx = (int)(currPos + 0.5f);

		for (int j = i ; j < frameNum && currIdx <= end ; j++)
		{
			currPos += colflowMap[j][currIdx];
			currIdx = (int)(currPos + 0.5f);

			if (currPos < end - 15.0f)
			{
				removed = true;
				rbound[i] = end / 2;
				break;
			} 
		}

		// look forward
		if (!removed)
		{
			currPos = rbound[i] - 5;
			currIdx = (int)(currPos + 0.5f);

			for (int j = i ; j >= 0 && currIdx <= end ; j--)
			{
				currPos += inv_colflowMap[j][currIdx];
				currIdx = (int)(currPos + 0.5f);

				if (currPos < end - 15.0f)
				{
					rbound[i] = end / 2;
					break;
				}
			}
		}
	}

	// static camera
	bool move = false;

	for (int i = 0 ; i < frameNum - 1 ; i++)
		if (lbound[i] != 0 && rbound[i] != end)
			move = true;

	if (move == false)
	{
		for (int i = 0 ; i < frameNum ; i++)
			lbound[i] = rbound[i] = end / 2;

		vector<int> avgCol;
		avgCol.resize(frameNum);

		for (int i = 0 ; i < frameNum ; i++)
			avgCol[i] = (leftBound[i] + rightBound[i]) / 2;

		float first = 0.0f , last = 0.0f;

		for (int i = 0 ; i < frameNum ; i++)
		{
			first += avgCol[i] * (1.0f - (float)i / (float)(frameNum - 1));
			last += avgCol[i] * ((float)i / (float)(frameNum - 1));
		}

		if (first > last)
		{
			rbound[0] = vWidth - 1;
			lbound[frameNum - 1] = 0;
		}
		else
		{
			rbound[frameNum - 1] = vWidth - 1;
			lbound[0] = 0;
		}
	}

	// update critical boundaries
	for (int i = 0 ; i < frameNum ; i++)
	{
		if (leftBound[i] > lbound[i])		leftBound[i] = lbound[i];
		if (rightBound[i] < rbound[i])		rightBound[i] = rbound[i];
	}

	lbound.clear();
	rbound.clear();
}

void manager_video::Render(bool trajectory , bool mesh , bool saliency)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();

	glPushMatrix();
	glTranslatef(ImagePos.x - 5.0f , ImagePos.y + Zoom * currRes.y + 10.0f , 0.0f);
	glScaled(Zoom , Zoom , 1.0f);

	glColor3f(1.0,1.0,1.0);

	// Render original frame
	RenderContent();

// 	glLineWidth(5.0);
// 
// 	glPushMatrix();
// 	glBegin(GL_LINES);
// 	glColor3f(1.0,0.0,0.0);
// 	glVertex2f(leftBound[frameIdx],0);
// 	glVertex2f(leftBound[frameIdx],vHeight);
// 
// 	glColor3f(1.0,0.0,0.0);
// 	glVertex2f(rightBound[frameIdx],0);
// 	glVertex2f(rightBound[frameIdx],vHeight);
// 	glEnd();
// 	glPopMatrix();

	//RenderFaceDetection();

	if(Render_result)
	{
		glPushMatrix();
		glTranslatef(0.0 ,  vHeight + 5 , 0.0f);
		RenderResult();

		// �N�h�X�����A�Υզ�x��B��
// 		glBegin(GL_QUADS);
// 		glColor3f(1.0,1.0,1.0);
// 			glVertex2f(0,-5);
// 			glVertex2f(-vWidth,-5);
// 			glVertex2f(-vWidth,vHeight+5);
// 			glVertex2f(0,vHeight+5);
// 
// 			glVertex2f(vWidth*resize_ratio.x,-5);
// 			glVertex2f(vWidth*resize_ratio.x+vWidth,-5);
// 			glVertex2f(vWidth*resize_ratio.x+vWidth,vHeight+5);
// 			glVertex2f(vWidth*resize_ratio.x,vHeight+5);
// 		glEnd();
 		glPopMatrix();
	}

	// render trajectory
	if(trajectory)    RenderTrajectory();

	// render Saliency
	if(saliency)      RenderSaliency();

	// Render mesh
	if(mesh)          RenderMesh();

// 	glTranslatef(0.0 ,  vHeight + 5 , 0.0f);
// 	glBegin(GL_LINES);
// 	glLineWidth(5.0);
// 	glColor3f(1.0,0.0,0.0);
// 	glVertex2f(image[frameIdx].critical_left_bound,0);
// 	glVertex2f(image[frameIdx].critical_left_bound,vHeight);
// 
// 	glColor3f(0.0,0.0,1.0);
// 	glVertex2f(image[frameIdx].critical_right_bound,0);
// 	glVertex2f(image[frameIdx].critical_right_bound,vHeight);
// 	glEnd();
	

	// �N�h�X�����A�Υզ�x��B��
 	glTranslatef(0.0 ,  vHeight + 5 , 0.0f);
	glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);
	glBegin(GL_QUADS);
	glColor3f(1.0,1.0,1.0);
	glVertex2f(0,-5);
	glVertex2f(-vWidth,-5);
	glVertex2f(-vWidth,vHeight+5);
	glVertex2f(0,vHeight+5);

	glVertex2f(vWidth*resize_ratio.x,-5);
	glVertex2f(vWidth*resize_ratio.x+vWidth,-5);
	glVertex2f(vWidth*resize_ratio.x,vHeight+5);
	glVertex2f(vWidth*resize_ratio.x,vHeight+5);
	glEnd();

	// render linear scale 
	RenderLinearSacle(mesh);

	//if(load_compare) RenderComparison();

	glPopMatrix();
	 
}

void manager_video::RenderComparison()
{
	int frameNum_com	= cvGetCaptureProperty( m_compare_capture , CV_CAP_PROP_FRAME_COUNT ) ;

	if(frameIdx < frameNum_com)
	{
		
		glColor3f(1.0,1.0,1.0);
		cvSetCaptureProperty( m_compare_capture , CV_CAP_PROP_POS_FRAMES , frameIdx);

		IplImage *temp_frame;
		temp_frame = cvQueryFrame( m_compare_capture );
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, temp_frame->width, temp_frame->height, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, temp_frame->imageData);

		glEnable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);

		glColor3f(1.0,1.0,1.0);
		glTranslatef(vWidth/2 + 5 ,0.0,0.0);
		glBegin(GL_QUADS);

		glTexCoord2f(0, 0);
		glVertex2f(0 , 0);

		glTexCoord2f(1, 0);
		glVertex2f(temp_frame->width ,0 );

		glTexCoord2f(1, 1);
		glVertex2f(temp_frame->width  ,  temp_frame->height );

		glTexCoord2f(0, 1);
		glVertex2f(0 , temp_frame->height);

		glEnd();

		glDisable(GL_TEXTURE_2D);

	}

	

}

void manager_video::RenderFaceDetection()
{
	glPolygonMode(GL_FRONT_AND_BACK , GL_LINE);
	glBegin(GL_QUADS);

	glColor3f(1.0,0.0,0.0);
	int face_detect_size = image[frameIdx].face_detect.size();
	for(int i = 0 ; i < face_detect_size ; ++i)
	{
		vector4 temp = image[frameIdx].face_detect[i];
		glVertex2f(temp.x,temp.y);
		glVertex2f(temp.z,temp.y);
		glVertex2f(temp.z,temp.w);
		glVertex2f(temp.x,temp.w);
	}

	glEnd();
}

void manager_video::RenderContent()
{
	glEnable(GL_TEXTURE_2D);
	glColor3f(1.0f , 1.0f , 1.0f);
	glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);

	int face_size = faceList.size();
	glBegin(GL_QUADS);

	

	for(int i = 0 ; i < face_size ; i++)
	{
		int vList[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

		glTexCoord2f(image[frameIdx].referenceList[vList[0]].x / vWidth, image[frameIdx].referenceList[vList[0]].y / vHeight);
		glVertex2f(image[frameIdx].referenceList[vList[0]].x , image[frameIdx].referenceList[vList[0]].y);


		glTexCoord2f(image[frameIdx].referenceList[vList[1]].x / vWidth, image[frameIdx].referenceList[vList[1]].y / vHeight);
		glVertex2f(image[frameIdx].referenceList[vList[1]].x , image[frameIdx].referenceList[vList[1]].y );


		glTexCoord2f(image[frameIdx].referenceList[vList[2]].x / vWidth, image[frameIdx].referenceList[vList[2]].y / vHeight);
		glVertex2f(image[frameIdx].referenceList[vList[2]].x , image[frameIdx].referenceList[vList[2]].y );


		glTexCoord2f(image[frameIdx].referenceList[vList[3]].x / vWidth, image[frameIdx].referenceList[vList[3]].y / vHeight);
		glVertex2f(image[frameIdx].referenceList[vList[3]].x , image[frameIdx].referenceList[vList[3]].y);
	}

	glEnd();
	glDisable(GL_TEXTURE_2D);
}
void manager_video::RenderTrajectory()
{
    
	// ��l�y��

	glPointSize(5.0);
	glBegin(GL_POINTS);
	glColor3f(0.0,1.0,0.0);
	int trajectory_size = image[frameIdx].trajectory.size();
	for(int i = 0 ; i < trajectory_size ; i++)
	{
		glColor3f(0.0,1.0,0.0);
		if(image[frameIdx].trajectory[i].x != -1 && image[frameIdx].trajectory[i].y != -1)
			glVertex2f(image[frameIdx].trajectory[i].x,image[frameIdx].trajectory[i].y);
	}
	glEnd();

	glPushMatrix();
	glTranslatef(0.0 ,  vHeight +  5 , 0.0f);
	if(Render_result)
	{
		glPointSize(5.0);

		glBegin(GL_POINTS);
		double move_width = image[frameIdx].critical_left_bound;
		//double move_width = 0;
		trajectory_size = image[frameIdx].trajectory_adjust.size();
		for(int i = 0 ; i < trajectory_size ; i++)
		{
				glColor3f(0.0,0.0,1.0);
				glVertex2f(image[frameIdx].trajectory_adjust[i].x - move_width,image[frameIdx].trajectory_adjust[i].y);
				glColor3f(1.0,0.0,0.0);
				glVertex2f(image[frameIdx].trajectory_final[i].x - move_width,image[frameIdx].trajectory_final[i].y);
		}
		glEnd();
	}
	glPopMatrix();

	/*
	
	    for(int i = 0 ; i < trajectory_size ; i++)
		{
	 			int number = image[frameIdx].trajectory_id[i];
	 			if(trajectory[number].neighbor_flag ==1 && trajectory[number].neighbor_start_frame == frameIdx)
	 			{
	 				int start_frame = trajectory[number].start_frame;
	 				int t_start_frame = trajectory[number].neighbor_start_frame; 
	 				int t_id = trajectory[number].pos[t_start_frame - start_frame];
	 				vector2 t_vertex = image[t_start_frame].trajectory[t_id]; 
	 				double index[4];
	 				index[0] = trajectory[number].neightbor.x;
	 				index[1] = trajectory[number].neightbor.y;
	 				index[2] = trajectory[number].neightbor.z;
	 				index[3] = trajectory[number].neightbor.w;

					
					
                    glColor3f(1.0,0.0,0.0);
	 
					glLineWidth(1.0);
					glBegin(GL_LINES);
					
	 				 
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[0]].x,image[t_start_frame].trajectory[(int)index[0]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[3]].x,image[t_start_frame].trajectory[(int)index[3]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[3]].x,image[t_start_frame].trajectory[(int)index[3]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[1]].x,image[t_start_frame].trajectory[(int)index[1]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[1]].x,image[t_start_frame].trajectory[(int)index[1]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[2]].x,image[t_start_frame].trajectory[(int)index[2]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[2]].x,image[t_start_frame].trajectory[(int)index[2]].y);
	 				glVertex2f(image[t_start_frame].trajectory[(int)index[0]].x,image[t_start_frame].trajectory[(int)index[0]].y);

					glEnd();

					glBegin(GL_POINTS);
					//glColor3f(1.0,0.0,0.0);
					     glVertex2f(image[frameIdx].trajectory[i].x,image[frameIdx].trajectory[i].y);
					glEnd();


	 			}
		}
	 	   
	*/
	
	
}
void manager_video::RenderSaliency()
{
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA);
	glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);

	int face_size = faceList.size();
	glBegin(GL_QUADS);
	for (int i = 0 ; i < face_size ; i++)
	{
		int	vIdx[4] = {faceList[i].x ,faceList[i].y , faceList[i].z ,faceList[i].w} ;
		vector3 color = image[frameIdx].GrayToColor(image[frameIdx].faceflexibleList[i]);

		glColor4f(color.x , color.y , color.z , 0.7f);
		glVertex2f(image[frameIdx].referenceList[vIdx[0]].x , image[frameIdx].referenceList[vIdx[0]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[1]].x , image[frameIdx].referenceList[vIdx[1]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[2]].x , image[frameIdx].referenceList[vIdx[2]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[3]].x , image[frameIdx].referenceList[vIdx[3]].y);
	}
	glEnd();

	glDisable(GL_BLEND);

}

void manager_video::RenderMesh()
{
	glLineWidth(1.0f);
	glColor3f(0.6f , 0.0f , 0.8f);
	glPolygonMode(GL_FRONT_AND_BACK , GL_LINE);

	int face_size = faceList.size();
	// ��lmesh
	glBegin(GL_QUADS);
	for (int i = 0 ; i < face_size ; i++)
	{
		int vIdx[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

		glVertex2f(image[frameIdx].referenceList[vIdx[0]].x , image[frameIdx].referenceList[vIdx[0]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[1]].x , image[frameIdx].referenceList[vIdx[1]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[2]].x , image[frameIdx].referenceList[vIdx[2]].y);
		glVertex2f(image[frameIdx].referenceList[vIdx[3]].x , image[frameIdx].referenceList[vIdx[3]].y);
	}
	glEnd();

	
	glPushMatrix();
	if(Render_result)
	{
		glTranslatef(0.0 ,  vHeight + 5 , 0.0f);
		glLineWidth(1.0f);
		glColor3f(0.6f , 0.0f , 0.8f);
		glPolygonMode(GL_FRONT_AND_BACK , GL_LINE);
        double move_width = image[frameIdx].critical_left_bound;
		//double move_width = 0;
		glBegin(GL_QUADS);
		for (int i = 0 ; i < face_size ; i++)
		{
			int vIdx[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

			glVertex2f(image[frameIdx].comparison[vIdx[0]].x - move_width, image[frameIdx].comparison[vIdx[0]].y);
			glVertex2f(image[frameIdx].comparison[vIdx[1]].x - move_width, image[frameIdx].comparison[vIdx[1]].y);
			glVertex2f(image[frameIdx].comparison[vIdx[2]].x - move_width, image[frameIdx].comparison[vIdx[2]].y);
			glVertex2f(image[frameIdx].comparison[vIdx[3]].x - move_width, image[frameIdx].comparison[vIdx[3]].y);
		}
		glEnd();
	}
	glPopMatrix();

}

void manager_video::RenderResult()
{

	glColor3f(1.0f , 1.0f , 1.0f);
	glEnable(GL_TEXTURE_2D);
	glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);

	int face_size = faceList.size();

	int rbIdx = image[frameIdx].rbIdx;

	glBegin(GL_QUADS);
	double move_width = image[frameIdx].critical_left_bound;
	//double move_width = 0.0;
	for(int i = 0 ; i < face_size ; i++)
	{
		int vList[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

		glTexCoord2f(image[frameIdx].referenceList[vList[0]].x / vWidth, image[frameIdx].referenceList[vList[0]].y / vHeight);
		if(image[frameIdx].referenceList[vList[0]].x == vWidth)
			glVertex2f(image[frameIdx].comparison[vList[0]].x - move_width + 1, image[frameIdx].comparison[vList[0]].y);
		else
            glVertex2f(image[frameIdx].comparison[vList[0]].x - move_width, image[frameIdx].comparison[vList[0]].y);

		glTexCoord2f(image[frameIdx].referenceList[vList[1]].x / vWidth, image[frameIdx].referenceList[vList[1]].y / vHeight);
		if(image[frameIdx].referenceList[vList[1]].x == vWidth)
			glVertex2f(image[frameIdx].comparison[vList[1]].x - move_width + 1 , image[frameIdx].comparison[vList[1]].y );
		else
            glVertex2f(image[frameIdx].comparison[vList[1]].x - move_width, image[frameIdx].comparison[vList[1]].y );

		glTexCoord2f(image[frameIdx].referenceList[vList[2]].x / vWidth, image[frameIdx].referenceList[vList[2]].y / vHeight);
		if(image[frameIdx].referenceList[vList[2]].x == vWidth)
			glVertex2f(image[frameIdx].comparison[vList[2]].x - move_width + 1, image[frameIdx].comparison[vList[2]].y );
		else
            glVertex2f(image[frameIdx].comparison[vList[2]].x - move_width, image[frameIdx].comparison[vList[2]].y );

		glTexCoord2f(image[frameIdx].referenceList[vList[3]].x / vWidth, image[frameIdx].referenceList[vList[3]].y / vHeight);
		if(image[frameIdx].referenceList[vList[3]].x == vWidth)
			glVertex2f(image[frameIdx].comparison[vList[3]].x - move_width + 1 , image[frameIdx].comparison[vList[3]].y);
		else
            glVertex2f(image[frameIdx].comparison[vList[3]].x - move_width  , image[frameIdx].comparison[vList[3]].y);
	}

	glEnd();

	glDisable(GL_TEXTURE_2D);
	

	
}

void manager_video::RenderLinearSacle(bool edge)
{
	if(Render_result)
	{
		glColor3f(1.0f , 1.0f , 1.0f);
		glPushMatrix();
		//glTranslatef(0.0 ,  vHeight + 5 , 0.0f);
		glEnable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT_AND_BACK , GL_FILL);

		glTranslatef(vWidth/2 + 5 ,0.0,0.0);
		glBegin(GL_QUADS);

		int face_size = faceList.size();

		for(int i = 0 ; i < face_size ; i++)
		{
			int vList[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

			glTexCoord2f(image[frameIdx].referenceList[vList[0]].x / vWidth, image[frameIdx].referenceList[vList[0]].y / vHeight);
			glVertex2f(image[frameIdx].referenceList[vList[0]].x / 2, image[frameIdx].referenceList[vList[0]].y);

			glTexCoord2f(image[frameIdx].referenceList[vList[1]].x / vWidth, image[frameIdx].referenceList[vList[1]].y / vHeight);
			glVertex2f(image[frameIdx].referenceList[vList[1]].x / 2, image[frameIdx].referenceList[vList[1]].y );

			glTexCoord2f(image[frameIdx].referenceList[vList[2]].x / vWidth, image[frameIdx].referenceList[vList[2]].y / vHeight);
			glVertex2f(image[frameIdx].referenceList[vList[2]].x / 2, image[frameIdx].referenceList[vList[2]].y );

			glTexCoord2f(image[frameIdx].referenceList[vList[3]].x / vWidth, image[frameIdx].referenceList[vList[3]].y / vHeight);
			glVertex2f(image[frameIdx].referenceList[vList[3]].x / 2, image[frameIdx].referenceList[vList[3]].y);
		}

		glEnd();

		glDisable(GL_TEXTURE_2D);

		if(edge)
		{
			glColor3f(0.6f , 0.0f , 0.8f);
			glPolygonMode(GL_FRONT_AND_BACK , GL_LINE);
			glBegin(GL_QUADS);
			for (int i = 0 ; i < face_size ; i++)
			{
				int vIdx[4] = {faceList[i].x , faceList[i].y , faceList[i].z , faceList[i].w};

				glVertex2f(image[frameIdx].referenceList[vIdx[0]].x / 2, image[frameIdx].referenceList[vIdx[0]].y);
				glVertex2f(image[frameIdx].referenceList[vIdx[1]].x / 2, image[frameIdx].referenceList[vIdx[1]].y);
				glVertex2f(image[frameIdx].referenceList[vIdx[2]].x / 2, image[frameIdx].referenceList[vIdx[2]].y);
				glVertex2f(image[frameIdx].referenceList[vIdx[3]].x / 2, image[frameIdx].referenceList[vIdx[3]].y);
			}
			glEnd();
		}

		glPopMatrix();
	}
}

void manager_video::RenderFlow()
{
	int point_piror = 10;
	glBegin(GL_LINES);
	glColor3f(0.0,1.0,0.0);
	for(int j = 0 ; j < vHeight ; j+=point_piror)
	{
		for(int i = 0 ; i < vWidth ; i+=point_piror)
		{
			glVertex2f(i,j);
			glVertex2f(i+opticalFlowU[frameIdx*vHeight*vWidth + j*vHeight + i],j+opticalFlowV[frameIdx*vHeight*vWidth + j*vHeight + i]);
		}

	}
	glEnd();
}

int manager_video::frameUpdate()
{
	static int acctime = 0;
	static TimeRecorder timer;

	float interval = 1.0f / vFPS;
	acctime += timer.PassedTime() * 1000;

	// �p�Gtimer�g�L���ɶ��j��1/FPS�AframeIdx++
	if (acctime >= interval)
	{
		frameIdx = (frameIdx + 1) % frameNum;
		acctime -= interval;
	}

	cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES , frameIdx);

	m_frame = cvQueryFrame( m_capture );
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, vWidth, vHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, m_frame->imageData);

	return frameIdx;
}
bool manager_video::setframe(int frame)
{
	frameIdx = frame;
	cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES , frameIdx);

	m_frame = cvQueryFrame( m_capture );
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, vWidth, vHeight, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, m_frame->imageData);

	
 
	return true;
}
void manager_video::SaveVideo(string filename)
{
	// �x�s�v�����j�p
	int img_width = (int)(currRes.x + 0.5f) + 15;
	int img_height = (int)(currRes.y + 0.5f)*2 + 20;

	if(img_width%2 == 1) img_width++;

	videoWriter = cvCreateVideoWriter(filename.c_str() , -1 , vFPS , cvSize(img_width , img_height) , 1);
	//videoWriter = cvCreateVideoWriter(filename.c_str() , CV_FOURCC('X', 'v', 'i', 'd') , vFPS , cvSize(img_width , img_height) , 1);
    
}
void manager_video::SaveFrame(bool video)
{
	static GLubyte *bits = NULL , *flipbits = NULL;
	static int rec_width = 0 ,   rec_height = 0;

	// �x�s�v�����j�p
	int img_width = (int)(currRes.x + 0.5f) + 15;
	int img_height = (int)(currRes.y + 0.5f)*2 + 20;

	if(img_width%2 == 1) img_width++;

	//int v_size =image[frameIdx].rbIdx;
	//int img_width = (int)image[frameIdx].vertexList[v_size].x;
	//int img_height = vHeight;


	if (rec_width != img_width || rec_height != img_height)
	{
		if (bits == NULL)		delete [] bits;
		if (flipbits == NULL)	delete [] flipbits;
		if (m_output == NULL)	delete m_output;

		rec_width = img_width;
		rec_height = img_height;

		bits = new GLubyte[rec_width * rec_height * 4];
		flipbits = new GLubyte[rec_width * rec_height * 4];

		m_output = new IplImage;
		memset((void *)m_output , 0 , sizeof(IplImage));


		m_output->nSize = sizeof(IplImage);
		m_output->align = 4;
		m_output->depth = 8;
		m_output->nChannels = 4;
		m_output->width = rec_width;
		m_output->height = rec_height;
		m_output->colorModel[0] = 'R';		m_output->colorModel[0] = 'G';		m_output->colorModel[0] = 'B';
		m_output->channelSeq[0] = 'B';		m_output->channelSeq[0] = 'G';		m_output->channelSeq[0] = 'R';
		m_output->imageSize = rec_width * rec_height * m_output->nChannels;
		m_output->widthStep = rec_width * m_output->nChannels;
		m_output->imageData = (char *)flipbits;
		m_output->imageDataOrigin = (char *)bits;
	}

	// result
	glReadPixels((int)ImagePos.x - 10.0f , (int)(panelSize.y - ImagePos.y - 3*currRes.y - 20.0f) , rec_width , rec_height , GL_BGRA_EXT , GL_UNSIGNED_BYTE , bits);

	// everything
	//glReadPixels((int)ImagePos.x - 5.0f , (int)(panelSize.y - ImagePos.y - currRes.y - 10.0f) , rec_width , rec_height , GL_BGRA_EXT , GL_UNSIGNED_BYTE , bits);
	//glReadPixels(ImagePos.x -5.0,  panelSize.y - ImagePos.y - 2*currRes.y -10.f, m_output->width , m_output->height , GL_BGRA_EXT , GL_UNSIGNED_BYTE , bits);


	for (int i = 0 ; i < rec_height ; i++)
		memcpy(	flipbits + i * m_output->widthStep , bits + (m_output->height - i - 1) * m_output->widthStep , m_output->widthStep);

	if (video)
		cvWriteFrame(videoWriter , m_output);
}
void manager_video::releaseSaving()
{
	cvReleaseVideoWriter(&videoWriter);
}

void manager_video::CriticalResize(int index , vector2 resolution , double avg_move )
{

	bool convergence = 1;

	while (convergence)
	{
		image[index].PatchDeformation(resolution , avg_move , faceList);

		float maxMovement = 0.0f;

		// �P�_���S������
		for (int j = 0 ; j < image[index].vertexNum ; ++j)
		{
			float length = (image[index].vertexList[j] - image[index].comparison[j]).length();

			if (length > maxMovement)
				maxMovement = length;
		}

		image[index].vertexList = image[index].comparison;

		if (maxMovement > 0.5f) {
			convergence = 1;
		}
		else {
			convergence = 0;
		}
	}

	//image[index].comparison = image[index].vertexList;

	
	image[index].solver.ResetSolver(0,0);
	image[index].solver.clean();
	

}

void manager_video::SingleFrameBound(int index)
{
	int rbIdx = image[index].rbIdx;

	int left = (float)leftBound[index] / image[index].xQuadSize;
	int right = (float)rightBound[index] / image[index].xQuadSize;

	//  critical region�b�̥���
	if(leftBound[index] == 0)
	{
		image[index].critical_left_bound  = 0;
		image[index].critical_right_bound = vWidth*resize_ratio.x;
	}
	else if(rightBound[index] == vWidth - 1)   //  critical region�b�̥k��
	{
		image[index].critical_right_bound = image[index].vertexList[rbIdx].x;
		image[index].critical_left_bound  = image[index].critical_right_bound - vWidth*resize_ratio.x;
	}
	else    //  critical region�b�����A���������٬O���k������A�����񪺪���cropping window
	{
		if(image[index].vertexList[left].x < image[index].vertexList[rbIdx].x - image[index].vertexList[right].x)
		{
			image[index].critical_left_bound = image[index].vertexList[left].x;
			image[index].critical_right_bound = image[index].critical_left_bound + vWidth*resize_ratio.x;
		}
		else
		{
			image[index].critical_right_bound = image[index].vertexList[right].x;
			image[index].critical_left_bound  = image[index].critical_right_bound - vWidth*resize_ratio.x;
		}

		//  �P�_���S���W�Xboundary
		if(image[index].critical_right_bound > image[index].vertexList[rbIdx].x)
		{
			image[index].critical_right_bound = image[index].vertexList[rbIdx].x;
			image[index].critical_left_bound  = image[index].critical_right_bound - vWidth*resize_ratio.x;
		}

		if(image[index].critical_left_bound < 0)
		{
			image[index].critical_right_bound = vWidth*resize_ratio.x;
			image[index].critical_left_bound  = 0;
		}

	}

}

void manager_video::SecondResize(int max_length)
{

	vector2 resolution;
	resolution.set(max_length , vHeight);

    #pragma omp parallel for
	for(int i = 0 ; i < frameNum ; ++i)
	{
		if(i!=0) image[i].vertexList = image[i-1].vertexList;
		CriticalResize(i,resolution,1);
	}

}

vector2 manager_video::ResizeMaxCritical(int critical_index)
{
	bool flag = 1;

	vector2 resolution;
	resolution.set(vWidth , vHeight);

	int left  = (float)leftBound[critical_index] / image[critical_index].xQuadSize;
	int right = (float)rightBound[critical_index] / image[critical_index].xQuadSize + 1;

	image[critical_index].Calculatecoeff(faceList);

	while(flag)
	{

		CriticalResize(critical_index,resolution,1);

		//  �P�_�O�_�Ncritical region���P�ҭn��resolution��
		if(image[critical_index].vertexList[right].x - image[critical_index].vertexList[left].x <= vWidth*resize_ratio.x) flag = 0;
		else                                                                                                  
		{
			resolution.x -= 10;
			flag = 1;
		}

		if(resolution.x <= vWidth*resize_ratio.x) 
		{
			resolution.x = vWidth*resize_ratio.x;
			flag = 0;
		}
	}

	return resolution;
}

void manager_video::FirstResizing(int critical_index , vector2 resolution)
{
	int part     = (frameNum) / 4;
	int part_1   = 1+part;
	int part_2   = 1+2*part;
	int part_3   = 1+3*part;
	int reminder = (frameNum) % 4;
	if(reminder == 1)
	{
		part_1++;
		part_2++;
		part_3++;
	}
	else if(reminder == 2)
	{
		part_1++;
		part_2+=2;
		part_3+=2;
	}
	else if(reminder == 3)
	{
		part_1++;
		part_2+=2;
		part_3+=3;
	}

	double avg_move = 0.01;

	resolution.x = vWidth * resize_ratio.x;


    #pragma omp parallel for
	for(int i = 0 ; i < frameNum ; ++i)
	{
		// �P�_���@��thread�n���ĴX��frame��resizing
		//   thread  1 2 3 4
		//   frame   1 40 80 120
		//           2 41 81 121
		//   �o�˰�����֡A���Oframe���|����
		int frame_Idx = i;		

		if(i == 0 || i == part_1 || i == part_2 || i== part_3) 
		{
			for(int j = 0 ; j < image[i].vertexNum ; ++j)
			{
				image[i].vertexList[j].x = image[i].referenceList[j].x  * resize_ratio.x;
				image[i].vertexList[j].y = image[i].referenceList[j].y  * resize_ratio.y;
			}

			//image[frame_Idx].vertexList = image[critical_index].vertexList;

		}
		else
		{
			if(frame_Idx != 0)  image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;
		}

		//if(frame_Idx != 0)
		//	 				image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;

		// conformal energy �Y�ƪ�l��
		if(frame_Idx != critical_index)
		{

			image[frame_Idx].coeff = new float*[8];
			for (int k = 0 ; k < 8 ; ++k)
			{
				image[frame_Idx].coeff[k] = new float[8];
			}

			for(int m = 0 ; m < 8 ; ++m)
			{
				for(int n = 0 ; n < 8 ; ++n)
					image[frame_Idx].coeff[m][n] = image[critical_index].coeff[m][n];
			}

// 			int t = rand() % 3 + 5;
// 			float temp = (float)t / 100;
// 			if(frame_Idx < 40)  temp = 0.07;
			CriticalResize(frame_Idx,resolution,avg_move);
		}

	}
}

void manager_video::AdjustKeyFrame()
{
	vector<int> temp_key_frame;

	// �P�_keyframe�O�_�s��A�p�G�s��h�R��
	int key_frame_size = key_frame.size();
	for(int i = 0 ; i < key_frame_size ; ++i)
	{
		if(i == 0)
			temp_key_frame.push_back(key_frame[i]);
		else
		{
			if(key_frame[i] == key_frame[i-1] + 1) ;
			else                                   
			{
				temp_key_frame.push_back(key_frame[i-1]);
				temp_key_frame.push_back(key_frame[i]);
			}
		}
	}

	temp_key_frame.push_back(frameNum-1);

	key_frame = temp_key_frame;
}

vector2 manager_video::calculateFinalResolution(int max_length)
{
	// �N�Ҧ�frame��resolution�[�`�D����
	vector2 resolution(vWidth,vHeight);
	float r_x = 0.0;
	for(int i = 0 ; i < frameNum ; ++i)
	{
		int rbIdx = image[i].rbIdx;
		if(image[i].vertexList[rbIdx].x > max_length)
			image[i].vertexList[rbIdx].x = max_length;

		r_x += image[i].vertexList[rbIdx].x;
	}

	r_x /= frameNum;

	if(r_x < vWidth*resize_ratio.x) r_x = vWidth*resize_ratio.x;

	resolution.x = r_x;

	return resolution;
}

int manager_video::findkeyframe()
{

    // find max critical region
	int max_length = 0; 
	int critical_index = frameNum /2;
	for(int i = 0 ; i < frameNum ; ++i)
	{
		int regionlength = rightBound[i] - leftBound[i];

		if(regionlength > max_length )//&& regionlength != vWidth - 1)
		{
			max_length = regionlength;
			critical_index = i;
		}
	}

	printf("\n\tFrame : %d , max critical region : %d\n",critical_index,max_length);

	// resize the max critical region frame to let the critical region smaller than vwidth * resize_ratio
	vector2 resolution;
	resolution.set(vWidth , vHeight);
	
	resolution = ResizeMaxCritical(critical_index);

	printf("\tFrame : %d , Resolution : %f\n",critical_index,resolution.x);

	if(abs(resolution.x - vWidth*resize_ratio.x) > 1)
	{
		// other frame resize the same resolution(critical_index frame)
		FirstResizing(critical_index , resolution);
	}
	else
	{
        FirstResizing_no_crop();
		for(int j = 0 ; j < frameNum ; ++j)
		{
			image[j].critical_left_bound = 0;
			image[j].critical_right_bound = vWidth*resize_ratio.x;
		}
		max_length = resolution.x;
	}
    resolution = calculateFinalResolution(resolution.x);

	printf("\tFinal Resolution : %f\n",resolution.x);


	return (int)(resolution.x+0.5);

}

void manager_video::FirstResizing_no_crop()
{
	int ver_size = image[0].vertexList.size();

	for(int j = 0 ; j < ver_size ; j++)
	{
		image[0].vertexList[j].x = image[0].referenceList[j].x  * resize_ratio.x;
		image[0].vertexList[j].y = image[0].referenceList[j].y  * resize_ratio.y;
	}

	image[0].Calculatecoeff(faceList);
	SingleFrameResize(0,1);

	//  �Ĥ@�� resizing other frame 
	int part     = (frameNum -1 ) / 4;
	int part_1   = 1+part;
	int part_2   = 1+2*part;
	int part_3   = 1+3*part;
	int reminder = (frameNum -1 ) % 4;
	if(reminder == 1)
	{
		part_1++;
		part_2++;
		part_3++;
	}
	else if(reminder == 2)
	{
		part_1++;
		part_2+=2;
		part_3+=2;
	}
	else if(reminder == 3)
	{
		part_1++;
		part_2+=2;
		part_3+=3;
	}


    #pragma omp parallel for
	for(int i = 1 ; i < frameNum ; ++i)
	{

		int frame_Idx = i;		

		if(i == part_1 || i == part_2 || i== part_3) 
		{
			for(int j = 0 ; j < image[i].vertexNum ; ++j)
			{
				image[i].vertexList[j].x = image[i].referenceList[j].x  * resize_ratio.x;
				image[i].vertexList[j].y = image[i].referenceList[j].y  * resize_ratio.y;
			}

		}
		else
		{
			image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;

		}

		//image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;

		// 		if(i < part_1 )                        frame_Idx = 1 + 4 * (i-1);
		// 		else if(i >= part_1 && i < part_2 )    frame_Idx = 2 + 4 * (i - part_1);
		// 		else if(i >= part_2  && i < part_3 )   frame_Idx = 3 + 4 * (i - part_2);
		// 		else                                   frame_Idx = 4 + 4 * (i - part_3 );
		// 		 
		// 		if(frame_Idx == 1 || frame_Idx == 2 || frame_Idx == 3 || frame_Idx == 4)      image[frame_Idx].vertexList = image[0].vertexList;
		// 		else                                                                          image[frame_Idx].vertexList = image[frame_Idx-4].vertexList;

		//image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;
		image[frame_Idx].coeff = new float*[8];
		for (int j = 0 ; j < 8 ; ++j)
		{
			image[frame_Idx].coeff[j] = new float[8];
		}

		for(int j = 0 ; j < 8 ; ++j)
		{
			for(int k = 0 ; k < 8 ; ++k)
				image[frame_Idx].coeff[j][k] = image[0].coeff[j][k];
		}


		SingleFrameResize(frame_Idx,1);	
	}
}

void manager_video::SingleFrameResize(int f_index , int number)
{
	bool convergence = 1;

	vector2 resolution(vWidth*resize_ratio.x , vHeight);
	while (convergence)
	{
		if(number == 1 ) image[f_index].PatchDeformation(resolution,1.0,faceList);
		if(number == 2 ) image[f_index].RefineDeformation(faceList);

		float maxMovement = 0.0f;

		for (int j = 0 ; j < image[f_index].vertexNum ; ++j)
		{
			float length = (image[f_index].vertexList[j] - image[f_index].comparison[j]).length();

			if (length > maxMovement)
				maxMovement = length;
		}

		image[f_index].vertexList = image[f_index].comparison;

		if (maxMovement > 0.5f) {
			convergence = 1;
		}
		else {
			convergence = 0;
		}
	}

	//image[f_index].comparison = image[f_index].vertexList;

	image[f_index].solver.ResetSolver(0,0);
	image[f_index].solver.clean();

}

void manager_video::FinalResize(int max_length)
{

	int rbIdx = image[0].rbIdx;

	double x_ratio = image[0].vertexList[rbIdx].x / vWidth;
	for(int j = 0 ; j < image[0].vertexNum ; j++)
	{
		image[0].vertexList[j].x = image[0].referenceList[j].x  * x_ratio;
		image[0].vertexList[j].y = image[0].referenceList[j].y  ;
	}


	SingleFrameResize(0,2);

	int part     = (frameNum -1 ) / 4;
	int part_1   = 1+part;
	int part_2   = 1+2*part;
	int part_3   = 1+3*part;
	int reminder = (frameNum -1 ) % 4;
	if(reminder == 1)
	{
		part_1++;
		part_2++;
		part_3++;
	}
	else if(reminder == 2)
	{
		part_1++;
		part_2+=2;
		part_3+=2;
	}
	else if(reminder == 3)
	{
		part_1++;
		part_2+=2;
		part_3+=3;
	}

    #pragma omp parallel for
	for(int i = 1 ; i < frameNum ; ++i)
	{
		// �P�_���@��thread�n���ĴX��frame��resizing
		//   thread  1 2 3 4
		//   frame   1 2 3 4
		//           5 6 7 8

		int frame_Idx = i;

		if(i < part_1 )                        frame_Idx = 1 + 4 * (i-1);
		else if(i >= part_1 && i < part_2 )    frame_Idx = 2 + 4 * (i - part_1);
		else if(i >= part_2  && i < part_3 )   frame_Idx = 3 + 4 * (i - part_2);
		else                                   frame_Idx = 4 + 4 * (i - part_3 );

		if(frame_Idx == 1 || frame_Idx == 2 || frame_Idx == 3 || frame_Idx == 4)      image[frame_Idx].vertexList = image[0].vertexList;
		else                                                                          image[frame_Idx].vertexList = image[frame_Idx-4].vertexList;

		//image[frame_Idx].vertexList = image[frame_Idx-1].vertexList;

		SingleFrameResize(frame_Idx,2);

		image[frame_Idx].solver.ResetSolver(0,0);
		image[frame_Idx].solver.clean();


	}

}

void manager_video::Video_Resizing(int width , int height)
{
	printf("Resizing Video....\n");

	printf("First Resizing......");

	double x_ratio = (float)width  / vWidth;
	double y_ratio = (float)height / vHeight;

	resize_ratio.set(x_ratio,y_ratio);

	double time_1 = clock();
	double time_4 = clock();

	//  ��iresize�̤j��resolution
    int max_length = findkeyframe();

	printf("%f second end\n",(clock()-time_1)/CLK_TCK);


	printf("Second Resizing......");

	time_1 = clock(); 


	if(abs(max_length - width) > 1) SecondResize(max_length);

	printf("%f second end\n",(clock()-time_1)/CLK_TCK);


	// �p��resizing�����y��
	CalculateResizingTrajectory();

	// �p��y��transform
	printf("Calculate trajectory transform......");
	time_1 = clock(); 
	TrajectoryTransform();
	printf("%f second end\n",(clock()-time_1)/CLK_TCK);

	printf("Third Resizing......");

	time_1 = clock(); 
	if(trajectory_error < 50)
	FinalResize(max_length);

	printf("%f second\n",(clock()-time_1)/CLK_TCK);

    CalculateCrop();
    
	Render_result = 1;
	
	printf("Total Time : %f seconds\n",(clock()-time_4)/CLK_TCK);
	
	CalculateFinalTrajectory(0 , frameNum);

	printf("Resizing Video done....\n");

	//similaritytransform();

	//saveTrajectory();
}

void manager_video::CalculateCrop()
{
	// find key frame : left bound = 0 || right bound = vwidth - 1 
	key_frame.clear();

	key_frame.push_back(0);
	for(int i = 1 ; i < frameNum - 1; i++)
	{
		if(leftBound[i] == 0 || rightBound[i] == vWidth-1)  key_frame.push_back(i);
	}

	key_frame.push_back(frameNum - 1);

	// find key frame cropping window
	int key_frame_size = key_frame.size();

	for(int i = 0 ; i < key_frame_size ; ++i)
	{
		int index = key_frame[i];
		SingleFrameBound(index);
	}

	// find frame between the key frame cropping window and add new key frame
	bool stop = 1;

	while(stop)
	{
		stop = FrameCropBound(1);

		key_frame_size = key_frame.size();
		for(int i = 0 ; i < key_frame_size ; ++i)
		{
			int index = key_frame[i];
			SingleFrameBound(index);
		}
	}

	// if key frame is continuous , then delete
	AdjustKeyFrame();

	FrameCropBound(2);

}

bool manager_video::FrameCropBound(int number)
{
	int key_frame_size = key_frame.size();

	vector<int> temp_key_frame;

	int left ,right;

	bool stop = 0;
	float max_dis = 0.0;
	int   max_index = -1;

	//  ��key frame����cropping window
	for(int i = 0 ; i < key_frame_size - 1 ; ++i)
	{
		int start_index = key_frame[i];
		int end_index   = key_frame[i+1];

		temp_key_frame.push_back(start_index);

		int rbIdx = image[0].rbIdx;

		int temp_width = image[start_index].vertexList[rbIdx].x;

		double left_1 , left_2;

        left_1 = image[start_index].critical_left_bound;
		left_2 = image[end_index].critical_left_bound;

		//printf("%d: %f , %d: %f\n",start_index,left_1,end_index,left_2);

		double mid_1 = left_1 + (left_2 - left_1)*0.3;
		double mid_2 = left_1 + (left_2 - left_1)*0.7;

		for(int j = start_index + 1 ; j < end_index ; ++j)
		{
            double t = float(j - start_index) / (end_index - start_index);

			//image[j].critical_left_bound = (1-t)*(1-t)*(1-t)*left_1 + 3*t*(1-t)*(1-t)*mid_1 + 3*(1-t)*t*t*mid_2 + t*t*t*left_2;
			image[j].critical_left_bound  = left_1 + (float)(left_2 - left_1) * (j-start_index) / ((end_index - start_index));
			image[j].critical_right_bound = image[j].critical_left_bound + vWidth / 2;
		
			left  = (float)leftBound[j] / image[j].xQuadSize;
			right = (float)rightBound[j] / image[j].xQuadSize +1;

			if(number == 1)
			{
				//  �P�_critical region�O�_�bcropping��
				//  �p�G�S���A�����̦h���s�Wkey frame
				if(image[j].vertexList[left].x - image[j].critical_left_bound < -2 || image[j].vertexList[right].x - image[j].critical_right_bound > 2)
				{
					
					int temp_index = temp_key_frame[temp_key_frame.size()-1];
					if(image[j].vertexList[left].x >= image[temp_index].critical_left_bound && image[j].vertexList[right].x <= image[temp_index].critical_right_bound) ;
					else
					{
						stop = 1;

						if(abs(image[j].vertexList[left].x - image[temp_index].critical_left_bound) > max_dis) 
						{
							max_dis = abs(image[j].vertexList[left].x - image[j].critical_left_bound);
							max_index = j;
						}

						if(abs(image[j].vertexList[right].x - image[temp_index].critical_right_bound) > max_dis) 
						{
							max_dis = abs(image[j].vertexList[left].x - image[j].critical_left_bound);
							max_index = j;
						}

					}

				}

			}
				
		}
		
	}

	if(stop == 1) 
	{
		temp_key_frame.push_back(max_index);

		int temp_key_size = temp_key_frame.size();
		for(int i = 0 ; i < temp_key_size - 1 ; ++i)
		{
			for(int j = i+1 ; j < temp_key_size ; ++j)
			{
				if(temp_key_frame[i] > temp_key_frame[j])
				{
					int temp = temp_key_frame[i];
					temp_key_frame[i] = temp_key_frame[j];
					temp_key_frame[j] = temp;

				}
			}
		}

	}

	temp_key_frame.push_back(frameNum-1);

	if(number == 1) key_frame = temp_key_frame;

	return stop;

}

float* manager_video::ToGrayImage(char *input , int size)
{
	static int buSize = 0;
	static float *buffer = NULL;

	// create memory
	if (buSize != size)
	{
		buSize = size;

		if (buffer != NULL)
		{
			delete [] buffer;
			buffer = NULL;
		}

		buffer = new float[buSize];
	}

	int shift = 0;

	// gray = (R+G+B) / 3
	for (int i = 0 ; i < buSize ; i++)
	{
		buffer[i] =	(float)(unsigned char)input[shift++] + 
			(float)(unsigned char)input[shift++] + 
			(float)(unsigned char)input[shift++];

		buffer[i] /= 765.0f;
	}

	return buffer;
}

void manager_video::CalculateOpticalFlow(int base)
{
	int ImgSize = vWidth * vHeight;

	// �p��optical flow

	setframe(base);
	flowlib.setInput( ToGrayImage(m_frame->imageData , ImgSize) , vWidth , vHeight , vWidth * sizeof(float) , false);

	for (int i = base ; i < base + flowSegment && i < frameNum - 1 ; ++i)
	{
		setframe(i + 1);
		//timer.ResetTimer();

		flowlib.setInput(ToGrayImage(m_frame->imageData , ImgSize) , vWidth , vHeight , vWidth * sizeof(float) , false);
		flowlib.runAlgorithm(0);
		flowlib.getFlowU((float *)&opticalFlowU[ (i % flowSegment)  * ImgSize] , vWidth * sizeof(float) , false);
		flowlib.getFlowV((float *)&opticalFlowV[ (i % flowSegment)  * ImgSize] , vWidth * sizeof(float) , false);

		//cout << "frame: " << i << ", takes " << timer.PassedTime() << " seconds." << endl;
	}
}

void manager_video::CalculateInverseFlow(int base)
{
	int ImgSize = vWidth * vHeight;

	// �p��optical flow

	for (int i = base ; i < base + flowSegment && i < frameNum - 1 ; ++i)
	{
		setframe(i + 1);
		flowlib.setInput(ToGrayImage(m_frame->imageData , ImgSize) , vWidth , vHeight , vWidth * sizeof(float) , false);

		setframe(i);
		flowlib.setInput(ToGrayImage(m_frame->imageData , ImgSize) , vWidth , vHeight , vWidth * sizeof(float) , false);

		flowlib.runAlgorithm(0);
		flowlib.getFlowU((float *)&inverseFlowU[ (i % flowSegment)  * ImgSize] , vWidth * sizeof(float) , false);
		flowlib.getFlowV((float *)&inverseFlowV[ (i % flowSegment)  * ImgSize] , vWidth * sizeof(float) , false);

	}
}

void manager_video::CalculateTrajectory(int base)
{

	if(base == 0)
	{
		InitialTrajectory(0);
		AddVertexface(0);
	}

	for(int i = base ; i <= base + flowSegment && i < frameNum  ; ++i)
	{
		if(i != base)
		{
			//�p��o��frame���y���m
			CalculateTrajectoryVertex(i);
			
			// �P�_�O�_�n�s�W�y��
			AddTrajectoryVertex(i);

		}

	}

}

void manager_video::CalculateMotionSaliency(int base)
{

	for(int i = base ; i < base + flowSegment && i < frameNum  ; ++i)
	{  
        // ����C�@�iframe��gradient saliency
		setframe(i);
		image[i].saliencyMeasure(m_saliency , faceList);
        //image[i].saliencyMeasureCanny(m_saliency,faceList);


		if(m_saliency)
		{
			if(i != frameNum -1)
			{
				// �A��C�@�iframe��motion saliency
				FrameMotionSalecnsy(i);

				combineSaliency(i);
			}
			else 
			{
				// �̫�@�i�S��motion�A�ҥH���e�@�i�����G�N��
				FrameMotionSalecnsy(i-1);

				image[i].MotionsaliencyMap = new float[vWidth * vHeight];

				image[i].MotionsaliencyMap  = image[i-1].MotionsaliencyMap;

				combineSaliency(i);

			}

		}
		else ;
	}
}

void manager_video::FrameMotionSalecnsy(int index)
{
	image[index].MotionsaliencyMap = new float[vWidth * vHeight];

	for(int i = 1 ; i < vWidth - 1 ; ++i)
	{
		for(int j = 1 ; j < vHeight - 1 ; ++j)
		{
			int x = i;
			int y = j;

			double motion_differ = 0.0;

			// motion gradient
			double flow_x = opticalFlowU[(index%flowSegment)*vWidth*vHeight + y*vWidth + x];
			double flow_y = opticalFlowV[(index%flowSegment)*vWidth*vHeight + y*vWidth + x];

			double flow_rx = opticalFlowU[(index%flowSegment)*vWidth*vHeight + y*vWidth + (x+1)];
			double flow_ry = opticalFlowV[(index%flowSegment)*vWidth*vHeight + y*vWidth + (x+1)];

			double flow_dx = opticalFlowU[(index%flowSegment)*vWidth*vHeight + (y+1)*vWidth + x];
			double flow_dy = opticalFlowV[(index%flowSegment)*vWidth*vHeight + (y+1)*vWidth + x];

			motion_differ += sqrt((flow_x - flow_rx)*(flow_x - flow_rx) + (flow_y - flow_ry)*(flow_y - flow_ry)) + sqrt((flow_x - flow_dx)*(flow_x - flow_dx) + (flow_y - flow_dy)*(flow_y - flow_dy)); 

			//motion_differ += abs(flow_x - flow_rx) + abs(flow_y - flow_ry) + abs(flow_x - flow_dx) + abs(flow_y - flow_dy); 

			if(motion_differ > max_differ) motion_differ = max_differ;
			image[index].MotionsaliencyMap[y*vWidth + i] = motion_differ;

		}
	}


	for(int i = 0 ; i < vWidth * vHeight ; ++i)
	{
		image[index].MotionsaliencyMap[i] /= max_differ;
		image[index].MotionsaliencyMap[i] = image[index].MotionsaliencyMap[i]*0.9 + 0.1;
	}

}

void manager_video::combineSaliency(int index)
{
	float *temp_saliency = new float[vWidth*vHeight];

	// ��motion�P�쥻saliency�֤j�N����
	for (int j = 0 ; j < vWidth ; j++)
	{
		for (int k = 0 ; k < vHeight ; k++)
		{
			if(image[index].MotionsaliencyMap[k*vWidth+j] > image[index].saliencyMap[k*vWidth+j])
				temp_saliency[k*vWidth+j] = image[index].MotionsaliencyMap[k*vWidth+j];
			else
				temp_saliency[k*vWidth+j] = image[index].saliencyMap[k*vWidth+j];
		}
	}

	// face detect���ϰ쬰1.0
	int face_detect_size = image[index].face_detect.size();
	for(int i = 0 ; i < face_detect_size ; ++i)
	{
		vector4 temp = image[index].face_detect[i];
		vector2 v1(temp.x,temp.y);
		vector2 v2(temp.z,temp.y);
		vector2 v3(temp.z,temp.w);
		vector2 v4(temp.x,temp.w);

		if(v1.x < 0 )     v1.x = 0;
		if(v1.x > vWidth) v1.x = vWidth;

		if(v3.x < 0 )     v3.x = 0;
		if(v3.x > vWidth) v3.x = vWidth;

		if(v1.y < 0 )      v1.y = 0;
		if(v1.y > vHeight) v1.y = vHeight;

		if(v3.y < 0 )      v3.y = 0;
		if(v3.y > vHeight) v3.y = vHeight;

		vector2 center((v1.x+v3.x)/2,(v1.y+v3.y)/2);

		float radius;

		if(abs(v1.x - v3.x) > abs(v1.y-v3.y)) radius = abs(v1.x - v3.x)/2;
		else                                  radius = abs(v1.y - v3.y)/2;

		for(int x = center.x - radius ; x <= center.x + radius ; ++x)
		{
			for(int y = center.y - radius ; y <= center.y + radius ; ++y)
			{
				if(x < 0 || x >= vWidth || y < 0 || y >= vHeight) ;
				else
				{
					int xIdx = x / image[index].xQuadSize;
					int yIdx = y / image[index].yQuadSize;
					int qIdx = yIdx * image[index].xGridSize + xIdx;

					double distance = sqrt((x - center.x)*(x - center.x) + (y - center.y)*(y - center.y));

					if(distance <= radius)
						temp_saliency[y*vWidth+x] = 1.0;
					//image[index].faceflexibleList[qIdx] = 1.0;
				}

			}
		}
	}

	image[index].faceflexibleList.resize(faceList.size());
	int face_size = image[index].faceflexibleList.size();
	for(int i = 0 ; i < face_size ; ++i)
		image[index].faceflexibleList[i] = 0;

	// �C�@��quad�ֿn��saliency
	for (int j = 0 ; j < vWidth ; j++)
	{
		for (int k = 0 ; k < vHeight ; k++)
		{
			int xIdx = j / image[index].xQuadSize;
			int yIdx = k / image[index].yQuadSize;
			int qIdx = yIdx * image[index].xGridSize + xIdx;

			image[index].faceflexibleList[qIdx] += temp_saliency[k * vWidth + j];
		}
	}

	float maxSaliency = 0.0f;

	

	// ��saliency�̤j��
	for (int i = 0 ; i < face_size ; i++)
	{
		if (maxSaliency < image[index].faceflexibleList[i])
			maxSaliency = image[index].faceflexibleList[i];
	}

	// normalize
	for (int i = 0 ; i < face_size ; i++)
	{
		image[index].faceflexibleList[i] /= maxSaliency;
		image[index].faceflexibleList[i] = image[index].faceflexibleList[i] * 0.9f + 0.1f ;
	}

	//printf("-------------------\n");

	delete [] image[index].MotionsaliencyMap;
	delete [] image[index].saliencyMap;
	delete [] temp_saliency;


}


void manager_video::findColFlows(int base)
{
// 	if (colflowMap.size() != frameNum)
// 	{
// 		colflowMap.resize(frameNum);
// 		inv_colflowMap.resize(frameNum);
// 
// 		for (int i = 0 ; i < frameNum ; i++)
// 		{
// 			colflowMap[i].resize(vWidth);
// 			inv_colflowMap[i].resize(vWidth);
// 
// 			for (int j = 0 ; j < vWidth ; j++)
// 			{
// 				colflowMap[i][j] = 0.0f;
// 				inv_colflowMap[i][j] = 0.0f;
// 			}
// 		}
// 	}

	// look back flow map
	for (int i = base ; i < base + flowSegment && i < frameNum - 1 ; i++)
	{
		for (int j = 0 ; j < vWidth ; j++)
			for (int k = 0 ; k < vHeight ; k++)
				colflowMap[i][j] += opticalFlowU[(i % flowSegment) * vWidth * vHeight + k * vWidth + j];

		for (int j = 0 ; j < vWidth ; j++)
			colflowMap[i][j] /= (float)vHeight;
	}

	// look forward flow map
	int *count = new int[vWidth];

	for (int i = base ; i < base + flowSegment && i < frameNum - 1 ; i++)
	{
		for (int j = 0 ; j < vWidth ; j++)
			count[j] = 0;

		for (int j = 0 ; j < vWidth ; j++)
		{
			int nextIdx = (int)(j + colflowMap[i][j] + 0.5f);

			if (nextIdx > 0 && nextIdx < vWidth)
			{
				count[nextIdx]++;
				inv_colflowMap[i + 1][nextIdx] += -colflowMap[i][j];
			}
		}

		for (int j = 0 ; j < vWidth ; j++)
			if (count[j] != 0)
				inv_colflowMap[i + 1][j] /= (float)count[j];

		// interpolation - if there is no flow projected at the column
		for (int j = 0 ; j < vWidth ; j++)
		{
			if (count[j] != 0)		continue;

			int left = j , right = j;

			while(count[left] == 0)
			{
				left--;
				if (left < 0)	break;
			}

			while(count[right] == 0)	
			{
				right++;
				if (right >= vWidth)	break;
			}

			if (left < 0 && right < vWidth)
			{
				count[j] = 1;
				inv_colflowMap[i + 1][j] = inv_colflowMap[i + 1][right];
			}
			else if (left >= 0 && right >= vWidth)
			{
				count[j] = 1;
				inv_colflowMap[i + 1][j] = inv_colflowMap[i + 1][left];
			}
			else if (left >= 0 && right < vWidth)
			{
				count[j] = 1;

				float ratio = (float)(j - left) / (float)(right - left);
				inv_colflowMap[i + 1][j] =	(1.0f - ratio ) * inv_colflowMap[i + 1][left] + 
					ratio * inv_colflowMap[i + 1][right];
			}
		}
	}

	delete [] count;
}

void manager_video::findActiveForegrounds( int base )
{

	//		run GPU function
	int fIdx = base ;

	//		change address , parallel every column
	for ( int h = 0 ; h < vHeight ; h++ )
		for ( int fStepIdx = 0 ; fStepIdx < stepFrame && fIdx+fStepIdx < frameNum - 1 ; fStepIdx++ )
			for ( int w = 0 ; w < vWidth ; w++ )
			{
				m_stepOpticalFlowU[h*stepFrame*vWidth + fStepIdx*vWidth + w] = opticalFlowU[fStepIdx*vHeight*vWidth + h*vWidth + w] ;
				m_stepOpticalFlowV[h*stepFrame*vWidth + fStepIdx*vWidth + w] = opticalFlowV[fStepIdx*vHeight*vWidth + h*vWidth + w] ;
			}

			//	memory copy : host to device
			cutilSafeCall( cudaThreadSynchronize() );	
			cutilSafeCall( cudaMemcpy( G_stepOptiFlowU	, m_stepOpticalFlowU , stepFrame*vWidth*vHeight*sizeof(float) , cudaMemcpyHostToDevice ) ) ;
			cutilSafeCall( cudaThreadSynchronize() );	
			cutilSafeCall( cudaMemcpy( G_stepOptiFlowV	, m_stepOpticalFlowV , stepFrame*vWidth*vHeight*sizeof(float) , cudaMemcpyHostToDevice ) ) ;

			//	run  
			cutilSafeCall( cudaThreadSynchronize() );
			cudaEntropyFlow( G_stepColAvgFlow , G_stepColEntropy , G_stepOptiFlowU , G_stepOptiFlowV , videoInfoData ) ;

			//	return : device to host
			cutilSafeCall( cudaThreadSynchronize() );
			cutilSafeCall( cudaMemcpy( m_allColEntropy + fIdx*vWidth , G_stepColEntropy , stepFrame*vWidth*sizeof(float) , cudaMemcpyDeviceToHost) ) ;
			cutilSafeCall( cudaThreadSynchronize() );
			cutilSafeCall( cudaMemcpy( m_allColAvgFlow + fIdx*vWidth , G_stepColAvgFlow , stepFrame*vWidth*sizeof(float) , cudaMemcpyDeviceToHost) ) ;
}

void manager_video::InitialTrajectory(int index)
{
	vector2 temp;
	int num = 0;
	for(int j = 0 ; j < image[index].vertexNum ; j++)
	{

		// �C�@��quad�����I���|�����y�񪺰_�l�I�Aboundary���~
		temp.set(image[index].referenceList[j].x,image[index].referenceList[j].y);

		if(temp.x == 0 || temp.y == 0 || temp.x == vWidth || temp.y == vHeight) ;
		else
		{

			trajectory_info temp_info;
			temp_info.number        = num;
			temp_info.start_frame   = index;
			temp_info.end_frame     = -1;
			temp_info.neighbor_flag = -1;

			image[index].trajectory.push_back(temp);
			image[index].trajectory_id.push_back(num);

			temp_info.pos.push_back(image[index].trajectory.size()-1);

			trajectory.push_back(temp_info);
			num++;
		}
	}
}

void manager_video::CalculateResizingTrajectory()
{
	  for(int i = 0 ; i < frameNum ; i++)
	  {
		  // trajectory_face�����o�@��trajectory�b�o�@��frame�O�_�s�b
		  // trajectory_face�ȵ��� -1 �A�N�����s�b
		  image[i].trajectory_resizing.resize(image[i].trajectory.size());
		  int trajectory_resizing_sizing = image[i].trajectory_resizing.size();

		  #pragma omp parallel for
		  for(int j = 0 ; j < trajectory_resizing_sizing ; ++j)
		  {
                  
				  // ��쥻�y�����quad�����Iweight�A���s��quad���I�A�ѭ쥻��weight�o��resizing�����y���m
				  vector2 v1 , v2 , v3 , v4 , v1_new , v2_new , v3_new , v4_new, p;
				  p       = image[i].trajectory[j];  

				  int xIdx = p.x / image[i].xQuadSize;
				  int yIdx = p.y / image[i].yQuadSize;
				  int face = yIdx * image[i].xGridSize + xIdx;

				  //int face = image[i].trajectory_face[j];
				  int vList[4] = { faceList[face].x , faceList[face].y , faceList[face].z , faceList[face].w };

				  
				  v1      = image[i].referenceList[vList[0]];     //�쥻��quad���I
				  v2      = image[i].referenceList[vList[1]];
				  v3      = image[i].referenceList[vList[2]];
				  v4      = image[i].referenceList[vList[3]];
				  v1_new  = image[i].vertexList[vList[0]];        //resizing����quad���I
				  v2_new  = image[i].vertexList[vList[1]];
				  v3_new  = image[i].vertexList[vList[2]];
				  v4_new  = image[i].vertexList[vList[3]];
				               // �쥻���y���m

				  double r1_x = (v2.x - p.x) / (v2.x - v1.x); 
				  double r1_y = (v3.y - p.y) / (v3.y - v1.y); 

				  double new_x = r1_y*(r1_x*v1_new.x + (1-r1_x)*v2_new.x) + (1 - r1_y)*(r1_x*v4_new.x + (1-r1_x)*v3_new.x);
				  double new_y = r1_y*(r1_x*v1_new.y + (1-r1_x)*v2_new.y) + (1 - r1_y)*(r1_x*v4_new.y + (1-r1_x)*v3_new.y);


				  //�p��resizing�����y���m
				  image[i].trajectory_resizing[j].x = new_x; 
				  image[i].trajectory_resizing[j].y = new_y; 
		  }

	  }
}

void manager_video::AddVertexface(int index)
{
	// �x�s�C�@�ӳ��I�b����face��
	  vertex_face.clear();
	  vertex_face.resize(image[index].vertexList.size());
	  int face_size = faceList.size();
	  for(int j = 0 ; j < face_size ; j++)
	  {
		int vList[4] = {faceList[j].x , faceList[j].y ,faceList[j].z , faceList[j].w};

		vertex_face[vList[0]].push_back(j);
		vertex_face[vList[1]].push_back(j);
		vertex_face[vList[2]].push_back(j);
		vertex_face[vList[3]].push_back(j);
	  }

}

void manager_video::CalculateTrajectoryVertex(int index)
{
	
	vector2 temp;

// 	cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES , index);
// 	m_frame = cvQueryFrame(m_capture);
// 	uchar *Frame_t = new uchar[vWidth*vHeight*3];
// 
// 	for(int j = 0 ; j < vWidth*vHeight*3 ; ++j) Frame_t[j] = m_frame->imageData[j];
// 
// 	cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES , index-1);
// 	m_frame = cvQueryFrame(m_capture);
// 	uchar *Frame_t_1 = new uchar[vWidth*vHeight*3];
// 
// 	for(int j = 0 ; j < vWidth*vHeight*3 ; ++j) Frame_t_1[j] = m_frame->imageData[j];

	int trajectory_ver_size = image[index-1].trajectory.size();

	for(int i = 0 ; i < trajectory_ver_size ; i++)
	{
		int j = image[index-1].trajectory_id[i];
		if(trajectory[j].end_frame == -1)
		{
			// Ū�e�@��frame���y���m�A�ǥ�optical flow�A�o��o��frame���y���m

			// temp�x�s�e�@��frame���y���m
			int pos_size = trajectory[j].pos.size();
			temp = image[index-1].trajectory[trajectory[j].pos[pos_size-1]];

			vector2 pos_1 = temp;

			//int face = image[index-1].trajectory_face[trajectory[j].pos[pos_size-1]];

			//��y���m�@4��5�J�s��x,y

			int x = temp.x;
			int y = temp.y;

			//vector2 pos(x,y);

			//int x = int(temp.x+0.5);
			//int y = int(temp.y+0.5);

			// Ū������optical flow
			float flow_x = opticalFlowU[((index-1)%flowSegment)*vWidth*vHeight + y*vWidth + x];
			float flow_y = opticalFlowV[((index-1)%flowSegment)*vWidth*vHeight + y*vWidth + x];

			temp.x +=  flow_x;
			temp.y +=  flow_y;

			bool color_differ = 0;

			int ix = int(temp.x+0.5);
			int iy = int(temp.y+0.5);

			float iflow_x;
			float iflow_y;

// 			if(ix < 0 || ix > vWidth -1 || iy < 0 || iy > vHeight -1) color_differ = 1;
// 			else
// 			{
// 				iflow_x = inverseFlowU[((index-1)%flowSegment)*vWidth*vHeight + iy*vWidth + ix];
// 				iflow_y = inverseFlowV[((index-1)%flowSegment)*vWidth*vHeight + iy*vWidth + ix];
// 
// 				vector2 inverse_p;
// 				inverse_p.set(temp.x + iflow_x,temp.y + iflow_y);
// 
// 				if((inverse_p-pos_1).length() > 3) color_differ = 1;
// 			}


			//if(abs(inverse_x - x) > 3 || abs(inverse_y - y) > 3) color_differ = 1;
			
			//if(color_stop) color_differ = colordifference(index,pos,pos_1,Frame_t,Frame_t_1);

			// �P�_���S���W�Xframe�d��A�p�G���A�y�񥢮�
			if(temp.x < 0 || temp.x > vWidth-1)         temp.x = -1;
			if(temp.y < 0 || temp.y > vHeight-1)        temp.y = -1;


			if(temp.x == -1 || temp.y == -1 || color_differ == 1 )  //�p�G�y�񥢮ġAface�笰����
			{
				trajectory[j].end_frame = index;
			}
			else                              //�p�G�y�񦳮ġA�x�s�y��
			{

				image[index].trajectory.push_back(temp);
				image[index].trajectory_id.push_back(trajectory[j].number);

				trajectory[j].pos.push_back(image[index].trajectory.size()-1);

			}

		}

	}

// 	delete [] Frame_t;
// 	delete [] Frame_t_1;
}

bool manager_video::colordifference(int index , vector2 pos , vector2 pos_1 , uchar * frame_t , uchar * frame_t_1)
{

	int x = pos.x;
	int y = pos.y;

	if(y >= vHeight)  y = vHeight -1;
	if(x >= vWidth)   x = vWidth  -1;

	if(y < 0)   y = 0;
	if(x < 0)   x = 0;

	int temp_x = pos_1.x ;
	int temp_y = pos_1.y ;

	if(temp_y >= vHeight)  temp_y = vHeight -1;
	if(temp_x >= vWidth)   temp_x = vWidth  -1;

	if(temp_y < 0)   temp_y = 0;
	if(temp_x < 0)   temp_x = 0;

	float total_differ = 0.0;

	int number = 0;

	int mask_ = 4; 

	if(x < mask_ || x >= vWidth - mask_ || y < mask_ || y >= vHeight - mask_ || temp_x < mask_ || temp_x >= vWidth -4 || temp_y < mask_ || temp_y >= vHeight - mask_)
	{

	}
	else
	{
		for(int m = -mask_ ; m <= mask_ ; ++m)
		{
			for(int n = -mask_ ; n <= mask_ ; ++n)
			{
				//int m = 0 , n = 0;

				int widthStep = image[index-1].Image->widthStep;
				uchar B = frame_t[(y+n)*widthStep + 3*(x+m)];
				uchar G = frame_t[(y+n)*widthStep + 3*(x+m) +1];
				uchar R = frame_t[(y+n)*widthStep + 3*(x+m) +2];

				uchar B1 = frame_t_1[(temp_y+n)*widthStep + 3*(temp_x+m)];
				uchar G1 = frame_t_1[(temp_y+n)*widthStep + 3*(temp_x+m) +1];
				uchar R1 = frame_t_1[(temp_y+n)*widthStep + 3*(temp_x+m) +2];

				float color_differ = (R1 - R)*(R1 - R) + (G1 - G)*(G1 - G) + (B1 - B)*(B1 - B);
				color_differ = sqrt(color_differ) / (255*1.732);

				if(color_differ > color_stop_threshold) number++;

			}
		}

	}

	bool stop = 0;
	if(number > (2*mask_+1)*(2*mask_+1) / 2)  stop = 1;
	
	return stop;
}

void manager_video::AddTrajectoryVertex(int index)
{
	vector<bool> S_face;
	S_face.resize(faceList.size());
	// �P�_����face�̦��y���I
	int trajectory_size = image[index].trajectory.size();
	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		vector2 temp = image[index].trajectory[i];

		int xIdx = temp.x / image[index].xQuadSize;
		int yIdx = temp.y / image[index].yQuadSize;
		int qIdx = yIdx * image[index].xGridSize + xIdx;

		S_face[qIdx] = 1;

	}

	int number = trajectory.size();
	for(int i = 0 ; i < image[index].vertexNum ; i++)
	{
		bool flag = 0;
		int v_face_size = vertex_face[i].size();
		// �P�_�o�ӳ��I�Ҧb��face���S���y���I�A�p�G���S���A�s�W
		for(int j = 0 ; j < v_face_size ; j++)
		{
			int face_index = vertex_face[i][j];
			if(S_face[face_index] == 1)
			{
				flag = 1;
				break;
			}
		}
		if(flag == 0)
		{
			vector2 temp;
			temp = image[index].referenceList[i];

	        if(temp.x == 0 || temp.y == 0 || temp.x == vWidth || temp.y == vHeight) ;
			else
			{

				if(temp.y == vHeight) temp.y = vHeight -1 ;
				if(temp.x == vWidth)  temp.x = vWidth - 1 ;

				image[index].trajectory.push_back(temp);
				image[index].trajectory_id.push_back(number);

				trajectory_info temp_info;
				temp_info.pos.push_back(image[index].trajectory.size()-1);
				temp_info.number = number;
				temp_info.start_frame = index;
				temp_info.end_frame   = -1;
				temp_info.neighbor_flag = -1;
				number++;
				trajectory.push_back(temp_info);

				S_face[vertex_face[i][0]] = 1;
			}
			

		}
	}
}

void manager_video::FindTrajectoryNeighbor()
{

	int trajectory_size = trajectory.size();

    #pragma omp parallel for
	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		int start_frame = trajectory[i].start_frame;
		int end_frame  = trajectory[i].end_frame;

		// �y��ӵu�A����F�~
		if(trajectory[i].length < 5)  trajectory[i].neighbor_flag = -1;
		else
		{
			//�p�G�o��frame�S�����A���U�@��frame��
			int find_frame = start_frame;

			FrameTrajectoryNeightbor(find_frame,i);

			find_frame++;
			while(find_frame < end_frame && trajectory[i].neighbor_flag == -1)
			{

				FrameTrajectoryNeightbor(find_frame,i);
				find_frame++;
			}
		}
	}    

}

void manager_video::FrameTrajectoryNeightbor(int f_index , int t_index)
{
	int start_frame = trajectory[t_index].start_frame; 
	int t_id = trajectory[t_index].pos[f_index - start_frame];
	vector2 t_vertex = image[f_index].trajectory[t_id];
	vector2 left(vWidth,t_id);
	vector2 right(vWidth,t_id);
	vector2 up(vHeight,t_id);
	vector2 down(vHeight,t_id);


	int trajectory_size = image[f_index].trajectory.size();
	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		int t_number = image[f_index].trajectory_id[i];

		// �p�G�F�~�ӵu�A����
		if(i == t_id || trajectory[t_number].end_frame - f_index < 5) ;
		else
		{
			// �P�_�O�_���̪񪺾F�~
			vector2 temp = image[f_index].trajectory[i];
			if(temp.x - t_vertex.x < -10.0  && temp.x - t_vertex.x > -2*image[f_index].xQuadSize && abs(temp.y - t_vertex.y) < 2*image[f_index].yQuadSize &&(temp - t_vertex).length() < left.x)
			{
				left.x = (temp - t_vertex).length();
				left.y = i;
			}
			else if(temp.x - t_vertex.x > 10.0 && temp.x - t_vertex.x < 2*image[f_index].xQuadSize && abs(temp.y - t_vertex.y) < 2*image[f_index].yQuadSize && (temp - t_vertex).length() < right.x)
			{
				right.x = (temp - t_vertex).length();
				right.y = i;
			}
			else if(temp.y - t_vertex.y < -10.0 && temp.y - t_vertex.y > -2*image[f_index].yQuadSize && abs(temp.x - t_vertex.x) < 2*image[f_index].xQuadSize && (temp - t_vertex).length() < up.x)
			{
				up.x = (temp - t_vertex).length();
				up.y = i;
			}
			else if(temp.y - t_vertex.y > 10.0 && temp.y - t_vertex.y < 2*image[f_index].yQuadSize && abs(temp.x - t_vertex.x) < 2*image[f_index].xQuadSize && (temp - t_vertex).length() < down.x)
			{
				down.x = (temp - t_vertex).length();
				down.y = i;
			}
			else ;
		}
	}

	if(left.y != t_id && right.y != t_id && up.y != t_id && down.y != t_id)
	{
		trajectory[t_index].neighbor_flag = 1;
		trajectory[t_index].neightbor.x = left.y;
		trajectory[t_index].neightbor.y = right.y;
		trajectory[t_index].neightbor.z = up.y;
		trajectory[t_index].neightbor.w = down.y;
		trajectory[t_index].neighbor_start_frame = f_index;
	}
}

void manager_video::InitialScale()
{

	int trajectory_size = trajectory.size();

	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		vector<double>  move_original;
		vector<double>  move_resizing;

		int trajectory_length = trajectory[i].length;
		int frameindex_start = trajectory[i].start_frame;

		for(int k = 0 ; k < trajectory_length ; ++k)
		{			 
			int t_index = trajectory[i].pos[k];

			move_original.push_back(image[k+frameindex_start].trajectory[t_index].x - trajectory[i].center_original.x);
			move_original.push_back(image[k+frameindex_start].trajectory[t_index].y - trajectory[i].center_original.y);

			move_resizing.push_back(image[k+frameindex_start].trajectory_resizing[t_index].x - trajectory[i].center_resize.x);
			move_resizing.push_back(image[k+frameindex_start].trajectory_resizing[t_index].y - trajectory[i].center_resize.y);
		}

		//��A

		vector<vector2> Ap;
		Ap.resize(2*trajectory_length);

		for(int k = 0 ; k < trajectory_length ; ++k)
		{
			Ap[2 * k + 0].x = move_original[2*k];
			Ap[2 * k + 0].y = 0.0;

			Ap[2 * k + 1].x = 0.0;
			Ap[2 * k + 1].y = move_original[2*k+1];
		}

		// ��ATA
		matrix <double> M(2,2);  
		matrix <double> M2(2,2);  
		for (int p = 0 ; p < 2 ; ++p)
		{
			for (int q = 0 ; q < 2 ; ++q)
			{
				M.setvalue(p,q,0.0);
				double ATA = 0;
				for (int m = 0 ; m < 2*trajectory_length ; ++m)
				{
					ATA +=Ap[m][p] * Ap[m][q];

				}
				M.setvalue(p,q,ATA);
				M2.setvalue(p,q,ATA);
			}

		}

		//ATA��inverse
		M.invert();

		vector<vector3> temp_matrix;
		temp_matrix.resize(2*trajectory_length);

		// (ATA)^-1 * AT
		for(int p = 0 ; p < 2 ; p++)
		{
			for(int q = 0 ; q < 2*trajectory_length ; q++)
			{
				bool M_success = 0;
				double M_p_0 , M_p_1;
				M.getvalue(p,0,M_p_0,M_success);
				M.getvalue(p,1,M_p_1,M_success);
				double temp = M_p_0*Ap[q][0] + M_p_1*Ap[q][1];
				temp_matrix[q][p] = temp;
			}
		}

		// T = (ATA)^-1 * AT * b
		double T[2] = {0};

		for(int p = 0 ; p < 2 ; p++)
		{
			for(int q = 0 ; q < 2*trajectory_length ; q++)
			{
				T[p] += temp_matrix[q][p]*move_resizing[q];
			}
		}

		trajectory[i].scale_x = T[0];
		trajectory[i].scale_y = T[1];

	}

}

void manager_video::TrajectoryTransform()
{
	for(int i = 0 ; i < frameNum ; ++i)
	{
		image[i].trajectory_adjust.resize(image[i].trajectory.size());
		//image[i].trajectory_reference.resize(image[i].trajectory.size());
		image[i].trajectory_final.resize(image[i].trajectory.size());
		image[i].trajectory_weight.resize(image[i].trajectory.size());

		int trajectory_size = image[i].trajectory.size();
		for(int j = 0 ; j < trajectory_size ; ++j)
		{
			image[i].trajectory_weight[j] = 0;
		}
	}

	int trajectory_size = trajectory.size();

	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		trajectory[i].center_original.set(0.0,0.0);
		trajectory[i].center_resize.set(0.0,0.0);
		for(int j = 0 ; j < trajectory[i].length ; ++j)
		{
			int t_index = trajectory[i].pos[j];
			trajectory[i].center_original += image[j+trajectory[i].start_frame].trajectory[t_index];
			trajectory[i].center_resize   += image[j+trajectory[i].start_frame].trajectory_resizing[t_index];
		}
		trajectory[i].center_original /= trajectory[i].length;
		trajectory[i].center_resize /= trajectory[i].length;

	}

	// �P�_�n���n�N�y�񲾨���I
	//if(move_center) InitialScale();

	// ��y��P�F�~������frame
	NeighborEndFrame();

	// ��transform
	AllTrajectoryTransform();

}

void manager_video::NeighborEndFrame()
{
	int trajectory_size = trajectory.size();
	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		if(trajectory[i].neighbor_flag == 1)
		{
			int neighbor_start_frame = trajectory[i].neighbor_start_frame;
			int left  = image[neighbor_start_frame].trajectory_id[(int)trajectory[i].neightbor.x];
			int right = image[neighbor_start_frame].trajectory_id[(int)trajectory[i].neightbor.y];
			int up    = image[neighbor_start_frame].trajectory_id[(int)trajectory[i].neightbor.z];
			int down  = image[neighbor_start_frame].trajectory_id[(int)trajectory[i].neightbor.w];

			// �ݭy��P�F�~�֤���������A��������frame
			if(trajectory[left].end_frame < trajectory[i].end_frame)  trajectory[i].neighbor_end_frame[0] = trajectory[left].end_frame;
			else                                                      trajectory[i].neighbor_end_frame[0] = trajectory[i].end_frame;

			if(trajectory[right].end_frame < trajectory[i].end_frame) trajectory[i].neighbor_end_frame[1] = trajectory[right].end_frame;
			else                                                      trajectory[i].neighbor_end_frame[1] = trajectory[i].end_frame;

			if(trajectory[up].end_frame < trajectory[i].end_frame)    trajectory[i].neighbor_end_frame[2] = trajectory[up].end_frame;
			else                                                      trajectory[i].neighbor_end_frame[2] = trajectory[i].end_frame;

			if(trajectory[down].end_frame < trajectory[i].end_frame)  trajectory[i].neighbor_end_frame[3] = trajectory[down].end_frame;
			else                                                      trajectory[i].neighbor_end_frame[3] = trajectory[i].end_frame;
			 

			// �P�F�~���G��frame�A4���O�_�n�@��
// 			int min_N = frameNum;
// 			 
// 			for(int p = 0 ; p < 4 ; ++p)
// 			{
// 				if(trajectory[i].neighbor_end_frame[p] < min_N) min_N = trajectory[i].neighbor_end_frame[p];
// 			}
// 			 
// 			for(int p = 0 ; p < 4 ; ++p)
// 			{
// 				 trajectory[i].neighbor_end_frame[p] = min_N;
// 			}
		}
	}
}

void manager_video::AllTrajectoryTransform()
{
	vector<int> trajectory_neighbor;
	vector<int> trajectory_length;


	int total_length = 0;
	int neighbor_length = 0;

	vector<int> length_id;
	length_id.resize(trajectory.size());

	int trajectory_size = trajectory.size();

	for(int i = 0 ; i < trajectory_size ; ++i)
	{
		if(trajectory[i].length >= transform_length)
		{
			
			trajectory_length.push_back(i);
            // �p�⥻���y�񪺪���
			length_id[i] = trajectory_length.size()-1;
			total_length += trajectory[i].length;

			// �p��y��P�F�~������
			if(trajectory[i].neighbor_flag == 1) 
			{
				trajectory_neighbor.push_back(i);
				neighbor_length += (trajectory[i].neighbor_end_frame[0] - trajectory[i].neighbor_start_frame);
				neighbor_length += (trajectory[i].neighbor_end_frame[1] - trajectory[i].neighbor_start_frame);
				neighbor_length += (trajectory[i].neighbor_end_frame[2] - trajectory[i].neighbor_start_frame);
				neighbor_length += (trajectory[i].neighbor_end_frame[3] - trajectory[i].neighbor_start_frame);
			}
		}
		else 
		{
			length_id[i] = -1;
		}
	}

	int length_size = trajectory_length.size();
	int neighbor_size = trajectory_neighbor.size();

	

	IterativeSolver  trajectory_solver;
	//GPULinearSolver trajectory_solver;

	int cols = 4 * trajectory_length.size() + 8 * trajectory_neighbor.size();
	int rows = 2 * total_length + 2 * neighbor_length;

	printf("\n\tcols:%d\n",cols);

	trajectory_solver.Create(rows, cols);

	float *B = NULL;
	float *x = NULL;

	B = new float[rows];
	x = new float[cols];

	int rowIdx = 0;

	double self_weight = 1.0;
	double neighbor_weight = 10.0;

	// ------------------------------------ set left  hand size matrix --------------------------------

	rowIdx = 0;
    // �y�񥻨�
	for(int k = 0 ; k < length_size ; ++k)
	{
		int index = trajectory_length[k];
		int start_frame = trajectory[index].start_frame;

		for(int p = 0 ; p < trajectory[index].length ; ++p)
		{
			int v_index = trajectory[index].pos[p];


			double x,y;

			if(move_center)
			{
				x = image[p + start_frame].trajectory[v_index].x - trajectory[index].center_original.x;
				y = image[p + start_frame].trajectory[v_index].y - trajectory[index].center_original.y;
			}
			else
			{
				x = image[p + start_frame].trajectory[v_index].x;
				y = image[p + start_frame].trajectory[v_index].y;
			}

			trajectory_solver.AddSysElement(rowIdx   , 4*k        , self_weight*x);
			trajectory_solver.AddSysElement(rowIdx++ , 4*k + 1    , self_weight*1.0);
			trajectory_solver.AddSysElement(rowIdx   , 4*k + 2    , self_weight*y);
			trajectory_solver.AddSysElement(rowIdx++ , 4*k + 3    , self_weight*1.0);	
		}
	}

	vector2 vertex_N , vertex_O;
    // �y��F�~
	for(int k = 0 ; k < neighbor_size ; ++k)
	{
		int index = trajectory_neighbor[k];
		int neighbor_start_frame = trajectory[index].neighbor_start_frame;

		int left  = image[neighbor_start_frame].trajectory_id[(int)trajectory[index].neightbor.x];
		int right = image[neighbor_start_frame].trajectory_id[(int)trajectory[index].neightbor.y];
		int up    = image[neighbor_start_frame].trajectory_id[(int)trajectory[index].neightbor.z];
		int down  = image[neighbor_start_frame].trajectory_id[(int)trajectory[index].neightbor.w];

		int max_N = 0;
		 			 
		for(int p = 0 ; p < 4 ; ++p)
		{
			if(trajectory[index].neighbor_end_frame[p] > max_N) max_N = trajectory[index].neighbor_end_frame[p];
		}


		for(int t = 0 ; t < 4 ; ++t)
		{
			int end_ = 0;
			if(t == 0)           end_ = trajectory[index].neighbor_end_frame[0];
			else if(t == 1)      end_ = trajectory[index].neighbor_end_frame[1];
			else if(t == 2)      end_ = trajectory[index].neighbor_end_frame[2];
			else                 end_ = trajectory[index].neighbor_end_frame[3];

			float weight = float(end_ - neighbor_start_frame) / (max_N - neighbor_start_frame);

			for(int p = neighbor_start_frame ; p < end_ ; ++p)
			{
				int N_ID ;

				if(t == 0) N_ID = trajectory[left].pos[p - trajectory[left].start_frame];
				if(t == 1) N_ID = trajectory[right].pos[p - trajectory[right].start_frame];
				if(t == 2) N_ID = trajectory[up].pos[p - trajectory[up].start_frame];
				if(t == 3) N_ID = trajectory[down].pos[p - trajectory[down].start_frame];

				int O_ID = trajectory[index].pos[p - trajectory[index].start_frame];

				vector2 vertex_N , vertex_O;

				vertex_N.set(image[p].trajectory[N_ID].x ,image[p].trajectory[N_ID].y);
				vertex_O.set(image[p].trajectory[O_ID].x ,image[p].trajectory[O_ID].y);

				int dir = 0;

				if(t == 0) dir = left;
				if(t == 1) dir = right;
				if(t == 2) dir = up;
				if(t == 3) dir = down;


                trajectory_solver.AddSysElement(rowIdx   , 4*length_id[index]                     , -vertex_O.x*neighbor_weight);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[index] + 1                 , -neighbor_weight*1.0);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[dir]                       , vertex_N.x*neighbor_weight);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[dir]   + 1                 , neighbor_weight*1.0);
				trajectory_solver.AddSysElement(rowIdx++ , 4*length_size      + 8 * k +2*t        , -weight*(vertex_N.x - vertex_O.x)*neighbor_weight);


				//--------------------------------------------------------------
				
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[index] + 2                 , -vertex_O.y*neighbor_weight);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[index] + 3                 , -neighbor_weight*1.0);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[dir]   + 2                 , vertex_N.y*neighbor_weight);
				trajectory_solver.AddSysElement(rowIdx   , 4*length_id[dir]   + 3                 , neighbor_weight*1.0);
				trajectory_solver.AddSysElement(rowIdx++ , 4*length_size      + 8 * k +2*t+ 1     , -weight*(vertex_N.y - vertex_O.y)*neighbor_weight);

			}
		}

	}

	// ------------------------------------ set right hand size matrix --------------------------------

	rowIdx = 0;
    // �y�񥻨�
	for(int k = 0 ; k < length_size ; ++k)
	{
		int index = trajectory_length[k];
		int start_frame = trajectory[index].start_frame;

		for(int p = 0 ; p < trajectory[index].length ; ++p)
		{
			int v_index = trajectory[index].pos[p];

			if(move_center)
			{
				B[rowIdx++] = self_weight*image[p + start_frame].trajectory_resizing[v_index].x - trajectory[index].center_resize.x;
				B[rowIdx++] = self_weight*image[p + start_frame].trajectory_resizing[v_index].y - trajectory[index].center_resize.y;
			}
			else
			{
				B[rowIdx++] = self_weight*image[p + start_frame].trajectory_resizing[v_index].x;
				B[rowIdx++] = self_weight*image[p + start_frame].trajectory_resizing[v_index].y;
			}

		}
	}

    // �y��F�~
	for(int k = 0 ; k < neighbor_length ; ++k)
	{
		B[rowIdx++] = 0;
		B[rowIdx++] = 0;

	}

	trajectory_solver.SetRightHandSideMatrix(B);

	// ------------------------------------------ initial guess ---------------------------------------

	rowIdx = 0;

	for(int k = 0 ; k < length_size ; ++k)
	{
		int index = trajectory_length[k];

		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
	}

	for(int k = 0 ; k < neighbor_size ; ++k)
	{
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
		x[rowIdx++] = 0.0;
	}

	trajectory_solver.SetInitialGuess(x);

	// ---------------------------------------------- solve -------------------------------------------

	//trajectory_solver.CholoskyFactorization();
	//trajectory_solver.CholoskySolve();
	//trajectory_solver.ConjugateGradientSolve();
    trajectory_solver.solve();

	rowIdx = 0;

	int count = 0;
	for(int k = 0 ; k < length_size ; ++k)
	{

		int t_index = trajectory_length[k];
		int start_frame = trajectory[t_index].start_frame;

		double scale_x     = trajectory_solver.GetSolution(4*rowIdx);
		double translate_x = trajectory_solver.GetSolution(4*rowIdx+1);
		double scale_y     = trajectory_solver.GetSolution(4*rowIdx+2);
		double translate_y = trajectory_solver.GetSolution(4*rowIdx+3);

		//printf("%f %f %f %f\n",scale_x,scale_y,translate_x,translate_y);

		trajectory[t_index].scale_x = scale_x;
		trajectory[t_index].scale_y = scale_y;
		trajectory[t_index].translate_x = translate_x;
		trajectory[t_index].translate_y = translate_y;

		//printf("-------------------------------------\n");
		if(abs(trajectory[t_index].scale_x) > 10 || abs(trajectory[t_index].scale_y) > 10)
		{
			count++;
		}

		//printf("(%f %f %f %f)\n",trajectory[t_index].scale_x,trajectory[t_index].scale_y,trajectory[t_index].translate_x,trajectory[t_index].translate_y);
        // �x�s���G
		for(int p = 0 ; p < trajectory[t_index].length ; ++p)
		{
			int v_index = trajectory[t_index].pos[p];

			if(move_center)
			{
				image[p + start_frame].trajectory_adjust[v_index].x = trajectory[t_index].scale_x * (image[p + start_frame].trajectory[v_index].x - trajectory[t_index].center_original.x) + trajectory[t_index].translate_x + trajectory[t_index].center_resize.x;
				image[p + start_frame].trajectory_adjust[v_index].y = trajectory[t_index].scale_y * (image[p + start_frame].trajectory[v_index].y - trajectory[t_index].center_original.y) + trajectory[t_index].translate_y + trajectory[t_index].center_resize.y;
			}
			else
			{
				image[p + start_frame].trajectory_adjust[v_index].x = trajectory[t_index].scale_x * image[p + start_frame].trajectory[v_index].x + trajectory[t_index].translate_x;
				image[p + start_frame].trajectory_adjust[v_index].y = trajectory[t_index].scale_y * image[p + start_frame].trajectory[v_index].y + trajectory[t_index].translate_y;
			}

			image[p + start_frame].trajectory_weight[v_index] = 1;

		}

		rowIdx++;
	}

	
	//trajectory_solver.ResetSolver(0,0);
	//trajectory_solver.clean();

	//delete []B;
	//delete []x;

	printf("\terror count:%d / %d \n",count ,length_size);

	trajectory_error = count;

}

void manager_video::saveTrajectory()
{

	FILE *fp1 , *fp2 , *fp3 , *fp4;

	int trajectory_size = trajectory.size();

	for(int i = 0 ; i < trajectory_size ; i++)
	{
		//if(trajectory[i].length == frameNum)
		//{
			string file_name_1 ="trajectory/trajectory_original-" + ConvertToString(i+1) + ".txt";
			//string file_name_2 ="trajectory/trajectory_deform-" + ConvertToString(i+1) + ".txt";
			//string file_name_3 ="trajectory/trajectory_adjust" + ConvertToString(i+1) + ".txt";
			string file_name_4 ="trajectory/trajectory_final" + ConvertToString(i+1) + ".txt";

			fp1 = fopen(file_name_1.c_str(),"w");
			//fp2 = fopen(file_name_2.c_str(),"w");
			//fp3 = fopen(file_name_3.c_str(),"w");
			fp4 = fopen(file_name_4.c_str(),"w");

			fprintf(fp1,"%d\n",trajectory[i].start_frame);
			//fprintf(fp2,"%d\n",trajectory[i].start_frame);
			//fprintf(fp3,"%d\n",trajectory[i].start_frame);
			fprintf(fp4,"%d\n",trajectory[i].start_frame);

			int start_frame = trajectory[i].start_frame;
			for(int j = 0 ; j < trajectory[i].length ; ++j)
			{
				int t_index = trajectory[i].pos[j];

				fprintf(fp1,"%f %f\n",image[start_frame+j].trajectory[t_index].x,image[start_frame+j].trajectory[t_index].y);
				//fprintf(fp2,"%f %f\n",image[start_frame+j].trajectory_resizing[t_index].x,image[start_frame+j].trajectory_resizing[t_index].y);
				//fprintf(fp3,"%f %f\n",image[start_frame+j].trajectory_adjust[t_index].x,image[start_frame+j].trajectory_adjust[t_index].y);
				fprintf(fp4,"%f %f\n",image[start_frame+j].trajectory_final[t_index].x,image[start_frame+j].trajectory_final[t_index].y);
			}

			
			fclose(fp1);
			//fclose(fp2);
			//fclose(fp3);
			fclose(fp4);	

		//}
		
	}

	printf("save success!!!!\n");
}

void manager_video::LoadTrajectory(string filename)
{

	fstream input;
	int col , row;
	input.open(filename.c_str() , ios::binary|ios::in);
	input.read((char *)&col , sizeof(int));
	input.read((char *)&row , sizeof(int));

	int index , index1;
	double val;

	printf("%d %d\n",col,row);

	for(int i = 0 ; i < 100 ; ++i)
	{
		input.read((char *)&index , sizeof(int));
		input.read((char *)&index1 , sizeof(int));
		input.read((char *)&val , sizeof(double));

		printf("%d %d %f\n",index,index1,val);
	}
	
	
// 	fstream input;
// 
// 	int trajectory_size = trajectory.size();
// 
// 	for(int i = 0 ; i < trajectory_size ; ++i)
// 	{
// 		if(trajectory[i].length >= transform_length)
// 		{
// 			trajectory[i].deform = 1;
// 			trajectory_length.push_back(i);
// 
// 			length_id[i] = trajectory_length.size()-1;
// 			total_length += trajectory[i].length;
// 
// 			if(trajectory[i].neighbor_flag == 1) 
// 			{
// 				trajectory_neighbor.push_back(i);
// 				//neighbor_length += (trajectory[i].neighbor_end_frame[0] - trajectory[i].neighbor_start_frame);
// 				neighbor_length += (trajectory[i].neighbor_end_frame[1] - trajectory[i].neighbor_start_frame);
// 				//neighbor_length += (trajectory[i].neighbor_end_frame[2] - trajectory[i].neighbor_start_frame);
// 				neighbor_length += (trajectory[i].neighbor_end_frame[3] - trajectory[i].neighbor_start_frame);
// 			}
// 		}
// 		else 
// 		{
// 			length_id[i] = -1;
// 			trajectory[i].deform = 0;
// 		}
// 	}

	/*
	int trajectory_size = image[frameNum-1].trajectory.size();

	int pos = filename.find_last_of("\\");
	string image_filename;
	int temp_pos = 0;
	while(temp_pos <= pos)
	{
		image_filename.push_back(filename[temp_pos]);

		temp_pos++;
	}
	for(int i = 0 ; i < trajectory_size ; i++)
	{
		string name = image_filename + "adjust" + ConvertToString(i+1) + ".txt";
		ifstream fp1(name.c_str());

		int trajectory_length = 0;
		int  j = i;
		int frameindex_start = 0;
		int face_size = image[frameindex_start].trajectory_face.size();
		while(frameindex_start < frameNum && face_size < i+1) frameindex_start++;

		int temp_index = frameindex_start;
		while(temp_index < frameNum && image[temp_index].trajectory_face[j] != -1) 
		{
			trajectory_length++;
			temp_index++;
		}

		int frameindex_end = temp_index;

		for(int k = frameindex_start ; k < frameindex_end ; k++)
		{
			double t_x = 0;
			fp1>>t_x;
			image[k].trajectory_reference[i].x =t_x ;
			
		}

		for(int k = frameindex_start ; k < frameindex_end ; k++)
		{
			double t_y = 0;
			fp1>>t_y;
			image[k].trajectory_reference[i].y = t_y;

		}

		fp1.close();


	}
	*/

	printf("Load trajectory end\n");
     
}

void manager_video::CalculateFinalTrajectory(int start_index , int end_index)
{

    for(int j = start_index ; j < end_index ; j++)
	{

		int trajectory_size = image[j].trajectory.size();
		image[j].trajectory_final.resize(trajectory_size);
        image[j].trajectory_final = image[j].trajectory_adjust;
		for(int i = 0 ; i < trajectory_size ; i++)
		{
			float weight = 1.0f;
			//if(image[j].trajectory_face[i] != -1)
			//{

			 vector2 v1 , v2 , v3 , v4 , v1_new , v2_new , v3_new , v4_new, p;
			 p       = image[j].trajectory[i];  
			int xIdx = p.x / image[j].xQuadSize;
			int yIdx = p.y / image[j].yQuadSize;
			int face = yIdx * image[j].xGridSize + xIdx;
				
				//weight = weight * faceflexibleList[face];
				  int vList[4] = { faceList[face].x , faceList[face].y , faceList[face].z , faceList[face].w };

				 // vector2 v1 , v2 , v3 , v4 , v1_new , v2_new , v3_new , v4_new, p;
				  v1      = image[j].referenceList[vList[0]];     //�쥻��quad���I
				  v2      = image[j].referenceList[vList[1]];
				  v3      = image[j].referenceList[vList[2]];
				  v4      = image[j].referenceList[vList[3]];
				  v1_new  = image[j].vertexList[vList[0]];        //resizing����quad���I
				  v2_new  = image[j].vertexList[vList[1]];
				  v3_new  = image[j].vertexList[vList[2]];
				  v4_new  = image[j].vertexList[vList[3]];
				               // �쥻���y���m
				  double a1 = ((v2.y - v3.y)*(p.x-v3.x)+(v3.x-v2.x)*(p.y-v3.y))/((v2.y - v3.y)*(v1.x-v3.x)+(v3.x-v2.x)*(v1.y-v3.y));
				  double b1 = ((v3.y - v1.y)*(p.x-v3.x)+(v1.x-v3.x)*(p.y-v3.y))/((v3.y - v1.y)*(v2.x-v3.x)+(v1.x-v3.x)*(v2.y-v3.y));
				  double c1 = ((v1.y - v2.y)*(p.x-v1.x)+(v2.x-v1.x)*(p.y-v1.y))/((v3.y - v1.y)*(v2.x-v1.x)-(v3.x-v1.x)*(v2.y-v1.y));

				  double new_x = v1_new.x + (p.x - v1.x)*(v2_new.x-v1_new.x) / (v2.x-v1.x);
				  double new_y = v1_new.y + (p.y - v1.y)*(v3_new.y-v1_new.y) / (v3.y-v1.y);

				  //�p��resizing�����y���m
				  image[j].trajectory_final[i].x = new_x; 
				  image[j].trajectory_final[i].y = new_y; 
				
			//}
		}
	} 
	
}


void manager_video::saveMesh(string filename)
{
	int pos = filename.find_last_of("\.");

	pos++;

	string mshName;

	int k = 0 ;
	while(k <pos) 
	{
		mshName.push_back(filename[k]);
		k++;
	}

	mshName.push_back('m');
	mshName.push_back('s');
	mshName.push_back('h');
	mshName.push_back('\0');

	fstream output;
	output.open(mshName.c_str() , ios::binary|ios::out);

	int num = image[0].vertexList.size();

	int total_num = num*frameNum;

	cout<<filename<<endl;

// 	for(int i = 0 ; i < frameNum ; i++)
// 	{
// 	  for(int j = 0 ; j < image[i].vertexNum ; ++j)
//        image[i].vertexList[j].x -= image[i].critical_left_bound;
// 	}

	char vFileName[255];

	vFileName[0] = '\0';

// 	for (int i = 0 ; i < filename.size() ; i++)
// 		vFileName[i] = filename[i];
// 
// 	vFileName[filename.size()] = '\0'; 

	output.write((char *)&vFileName , 255 * sizeof(char));
	output.write((char *)&image[0].gridRes , sizeof(int));
	//output.write((char *)&frameNum , sizeof(int));
	output.write((char *)&total_num , sizeof(int));
	for(int i = 0 ; i < frameNum ; i++)
	{
		output.write((char *)&image[i].vertexList[0] , num * sizeof(vector2));
		//output.write((char *)&image[i].comparison[0] , num * sizeof(vector2));
	}

// 	for(int i = 0 ; i < frameNum ; i++)
// 	{
// 		output.write((char *)&image[i].critical_left_bound , sizeof(float));
// 	}

	output.write((char *)&currRes , sizeof(vector2));

	output.close();

	printf("save mesh at %s\n",mshName.c_str());

}

void manager_video::loadMesh(string filename)
{
	fstream input;
	char buffer[255];
	int  num , gridRes;

	input.open(filename.c_str() , ios::binary|ios::in);
	input.read((char *)&buffer , 255 * sizeof(char));

	input.read((char *)&gridRes , sizeof(int));
	//input.read((char *)&frameNum , sizeof(int));
	input.read((char *)&num , sizeof(int));

	int pos = filename.find_last_of(".");

	pos++;

	string videoName;

	int k = 0 ;
	while(k <pos) 
	{
		videoName.push_back(filename[k]);
		k++;
	}

	videoName.push_back('a');
	videoName.push_back('v');
	videoName.push_back('i');
	videoName.push_back('\0');

	cout<<videoName<<endl;


	if (m_capture != NULL)
	{
		cvReleaseCapture(&m_capture);
		m_capture = NULL;
	}

	m_capture	= cvCaptureFromFile( videoName.c_str() );
	frameNum	= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_COUNT ) ;
	vWidth		= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_WIDTH ) ;
	vHeight	    = cvGetCaptureProperty( m_capture , CV_CAP_PROP_FRAME_HEIGHT ) ;
	vFPS		= cvGetCaptureProperty( m_capture , CV_CAP_PROP_FPS ) ;

	cvSetCaptureProperty( m_capture , CV_CAP_PROP_POS_FRAMES  , 0 ) ;

	if (frameNum == 0 || vWidth == 0 || vHeight == 0 || vFPS == 0)
	{
		cout << "file loading failed!" << endl;
	}
	else
	{
		cout << "------------------- video information ---------------------" << endl;
		cout << "width = " << vWidth << " , height = " << vHeight << " , fps = " << vFPS << " , frames = " << frameNum << endl;
	}

	//delete [] image;

	image = new manager_image[frameNum];

	for( int i = 0 ; i < frameNum ; i++ )
	{
		image[i].Image_width  = vWidth;
		image[i].Image_height = vHeight;

		image[i].gridRes = gridRes;
		image[i].CreateQuadMesh();

		image[i].comparison.resize(image[i].vertexList.size());
		image[i].comparison = image[i].vertexList;

		//input.read((char *)&image[i].vertexList[0] , image[i].vertexNum * sizeof(vector2));
		input.read((char *)&image[i].comparison[0] , image[i].vertexNum *  sizeof(vector2));
	}

// 	for(int i = 0 ; i < frameNum ; i++)
// 	{
//         input.read((char *)&image[i].critical_left_bound , sizeof(float));
// 	}

	//input.read((char *)&currRes , sizeof(vector2));
	input.close();

	currRes.set(vWidth,vHeight);

	ImagePos.set(20.0f , 20.0f);

	Zoom = 1.0;

	Render_result = 1;

	load_compare = 0;

// 	// face list
	faceList.resize(image[0].xGridSize * image[0].yGridSize);

	for (int j = 0 ; j < image[0].xGridSize ; j++)
	{
		for (int k = 0 ; k < image[0].yGridSize ; k++)
		{
			int Idx = k * (image[0].xGridSize + 1) + j;

			faceList[k * image[0].xGridSize + j].x = Idx;
			faceList[k * image[0].xGridSize + j].y = Idx + 1;
			faceList[k * image[0].xGridSize + j].z = Idx + image[0].xGridSize + 2;
			faceList[k * image[0].xGridSize + j].w = Idx + image[0].xGridSize + 1;

		}
	}
	
}


void manager_video::LoadCompareVideo(string filename)
{
	m_compare_capture           = NULL;

	m_compare_capture	= cvCaptureFromFile( filename.c_str() );
	int frameNum_com	= cvGetCaptureProperty( m_compare_capture , CV_CAP_PROP_FRAME_COUNT ) ;
	int vWidth_com		= cvGetCaptureProperty( m_compare_capture , CV_CAP_PROP_FRAME_WIDTH ) ;
	int vHeight_com  	= cvGetCaptureProperty( m_compare_capture , CV_CAP_PROP_FRAME_HEIGHT ) ;
	int vFPS_com		= cvGetCaptureProperty( m_compare_capture , CV_CAP_PROP_FPS ) ;

	if (frameNum_com == 0 || vWidth_com == 0 || vHeight_com == 0 || vFPS_com == 0)
	{
		cout << "file loading failed!" << endl;
	}
	else
	{
		cout << "-------------------comparison video information ---------------------" << endl;
		cout << "width = " << vWidth_com << " , height = " << vHeight_com << " , fps = " << vFPS_com << " , frames = " << frameNum_com << endl;

		load_compare = 1;
	}

}

void manager_video::similaritytransform()
{

	int trajectory_size = trajectory.size();

	simi_transform.resize(trajectory_size);

	for(int i = 0 ; i < trajectory_size ; ++i)
	{

		if(trajectory[i].length == frameNum)
		{
			vector<double>  move_original;
			vector<double>  move_resizing;

			int trajectory_length = trajectory[i].length;
			int frameindex_start = trajectory[i].start_frame;

			for(int k = 0 ; k < trajectory_length ; ++k)
			{			 
				int t_index = trajectory[i].pos[k];

				move_original.push_back(image[k+frameindex_start].trajectory[t_index].x);
				move_original.push_back(image[k+frameindex_start].trajectory[t_index].y);

				move_resizing.push_back(image[k+frameindex_start].trajectory_resizing[t_index].x);
				move_resizing.push_back(image[k+frameindex_start].trajectory_resizing[t_index].y);
			}

			//��A

			vector<vector4> Ap;
			Ap.resize(2*trajectory_length);

			for(int k = 0 ; k < trajectory_length ; ++k)
			{
				Ap[2 * k + 0].x = move_original[2*k];
				Ap[2 * k + 0].y = move_original[2*k+1];
				Ap[2 * k + 0].z = 1.0;
				Ap[2 * k + 0].w = 0.0;

				Ap[2 * k + 1].x = move_original[2*k+1];
				Ap[2 * k + 1].y = -move_original[2*k];
				Ap[2 * k + 1].z = 0.0;
				Ap[2 * k + 1].w = 1.0;
			}

			// ��ATA
			matrix <double> M(4,4);  
			matrix <double> M2(4,4);  
			for (int p = 0 ; p < 4 ; ++p)
			{
				for (int q = 0 ; q < 4 ; ++q)
				{
					M.setvalue(p,q,0.0);
					double ATA = 0;
					for (int m = 0 ; m < 2*trajectory_length ; ++m)
					{
						ATA +=Ap[m][p] * Ap[m][q];

					}
					M.setvalue(p,q,ATA);
					M2.setvalue(p,q,ATA);
				}

			}

			//ATA��inverse
			M.invert();

			vector<vector4> temp_matrix;
			temp_matrix.resize(2*trajectory_length);

			// (ATA)^-1 * AT
			for(int p = 0 ; p < 4 ; p++)
			{
				for(int q = 0 ; q < 2*trajectory_length ; q++)
				{
					bool M_success = 0;
					double M_p_0 , M_p_1,M_p_2,M_p_3;
					M.getvalue(p,0,M_p_0,M_success);
					M.getvalue(p,1,M_p_1,M_success);
					M.getvalue(p,2,M_p_2,M_success);
					M.getvalue(p,3,M_p_3,M_success);
					double temp = M_p_0*Ap[q][0] + M_p_1*Ap[q][1] + M_p_2*Ap[q][2] + M_p_3*Ap[q][3];
					temp_matrix[q][p] = temp;
				}
			}

			// T = (ATA)^-1 * AT * b
			double T[4] = {0};

			for(int p = 0 ; p < 4 ; p++)
			{
				for(int q = 0 ; q < 2*trajectory_length ; q++)
				{
					T[p] += temp_matrix[q][p]*move_resizing[q];
				}
			}

			simi_transform[i].x = T[0];
			simi_transform[i].y = T[1];
			simi_transform[i].z = T[2];
			simi_transform[i].w = T[3];

// 			float error = 0.0;
// 			for(int k = 0 ; k < trajectory_length ; ++k)
// 			{
// 				float temp_x = move_original[2*k]*T[0] - move_original[2*k+1]*T[1] + T[2];
// 				float temp_y = move_original[2*k+1]*T[0] + move_original[2*k+0]*T[1] + T[3];
// 
// 				error += abs(temp_x - move_resizing[0]) + abs(temp_y - move_resizing[1]);
// 			}

			//float temp_x = move_original[0]*T[0] - move_original[1]*T[1] + T[2];
			//float temp_y = move_original[1]*T[0] + move_original[0]*T[1] + T[3];

			//float error = abs(temp_x - move_resizing[0]) + abs(temp_y - move_resizing[1]);

			//printf("%f\t",error / trajectory_length);
		}

		

	}

}