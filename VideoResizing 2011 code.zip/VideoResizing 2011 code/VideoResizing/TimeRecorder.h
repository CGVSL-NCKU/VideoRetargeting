#ifndef TIMERECORDER
#define TIMERECORDER

#include <MMSystem.h>
#include <Windows.h>

// Linker: winmm.lib

class TimeRecorder
{
public:
	TimeRecorder()
	{
		ResetTimer();
	}

	~TimeRecorder()
	{
		tickCount = 0;
		last_tickCount = 0;
	}

	void ResetTimer()
	{
		tickCount = last_tickCount = timeGetTime();
	}

	float PassedTime()
	{
		tickCount = timeGetTime();
		return (float)(tickCount - last_tickCount) / 1000.0f;
	}

private:
	DWORD tickCount , last_tickCount;
};

#endif