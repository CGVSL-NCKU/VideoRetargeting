#ifndef ITERATIVE_SOLVER_H
#define ITERATIVE_SOLVER_H

#include <Windows.h>
#include <stdlib.h>
#include <vector>

#include "TimeRecorder.h"

extern "C"
{
	#include <cs.h>
};

using namespace std;
#pragma comment(lib, "CSparse.lib")

class IterativeSolver
{
public:

	IterativeSolver()
	{
		A = triplet = NULL;
		cols = rows = 0;
		Is_System_Stable = Is_RHS_Stable = false;
	}

	~IterativeSolver()
	{
		deallocate();
	}

	bool IsTheSameSize(int rowNum , int colNum)
	{
		if (rows == rowNum && cols == colNum)
			return true;
		else
			return false;
	}

	void Create(int rowNum , int colNum)
	{
		rows = rowNum;
		cols = colNum;
		Is_System_Stable = Is_RHS_Stable = false;

		AllocateSystemMatrix();
		AllocateRightHandSideMatrix();
	}

	void ResetSolver(int rowNum , int colNum)
	{
		deallocate();
		Create(rowNum , colNum);
	}

	void AddSysElement(int rowIdx , int colIdx , float val)
	{
		if (rowIdx >= rows || colIdx >= cols)
			printf("Warning! An index of the system matrix is wrong! %d %d %d %d\n", rowIdx , rows , colIdx , cols );

		cs_entry(triplet , rowIdx , colIdx , val);

		Is_System_Stable = false;
	}

	void SetRightHandSideMatrix(float *m)
	{
		b = m;
		Is_RHS_Stable = false;
	}

	float GetSolution(int rowIdx)
	{
		return x[rowIdx];
	}

	void SetInitialGuess(float *m)
	{
		for (unsigned i = 0 ; i < cols ; i++)
			x[i] = m[i];
	}

	void matrixStablization()
	{
// 		if(triplet != NULL && triplet->nz > 5000000)
// 		{
// 			ofstream output;
// 			output.open("matrix_correct.out" , ios:: out);
// 
// 			output << rows << " " << cols << " " << triplet->nz << endl;
// 
// 			for (int i = 0 ; i < triplet->nz ; i++)
// 				output << triplet->i[i] << " " << triplet->p[i] << " " << triplet->x[i] << endl;
// 
// // 			for (int i = 0 ; i < cols ; i++)
// // 				output << x[i] << endl;
// // 
// // 			for (int i = 0 ; i < rows ; i++)
// // 				output << b[i] << endl;
// 
// 			output.close();
// 
// 		}

		//printf("ATA\n");
		if (!Is_System_Stable)		LeastSquareToGeneralSparseMatrix();
        //printf("ATB\n");
		if (!Is_RHS_Stable)			ATbComputation();



	}

	void solve(float epsilon = 0.001f , int max_iter = 5000)
	{
		//TimeRecorder timer;
		//timer.ResetTimer();
        
		matrixStablization();
		//printf("solve\n");
		ConjugateGradient(epsilon , max_iter);

		//printf("passed time: %f\n" , timer.PassedTime());
	}

	void clean()
	{

		if (ATA != NULL)
		{
			cs_spfree(ATA);
			ATA = NULL;
		}
	}

private:
	int cols , rows;
	bool Is_System_Stable , Is_RHS_Stable;

	// Sparse/Dense matrix for GPU
	float *ATb , *x;
	
	// Sparse/Dense matrix for CPU
	float *b;
	cs *triplet , *A , *ATA;

	void deallocate()
	{
		if (x != NULL)
		{
			delete [] x;
			x = NULL;
		}

		if (ATb != NULL)
		{
			delete [] ATb;
			ATb = NULL;
		}

		if (A != NULL)
		{
			cs_spfree(A);
			A = NULL;
		}

		if (triplet != NULL)
		{
			cs_spfree(triplet);
			triplet = NULL;
		}
	}

	void AllocateSystemMatrix()
	{
		x = new float[cols];

		for (int i = 0 ; i < cols ; i++)
			x[i] = 0.0f;
	
		triplet = cs_spalloc(rows , cols , rows , 1 , 1);
	}

	void AllocateRightHandSideMatrix()
	{
		ATb = new float[cols];
	}

	void LeastSquareToGeneralSparseMatrix()
	{

		//printf("triplet:%d\n",triplet->nz);
		
		cs *AT;
		A = cs_compress(triplet);

		//printf("%d\n",A->nz);

		if(A == NULL) printf("A fail\n");


		// --------------- Saving more memory space --------------------
		// Warning!! should be very careful, you cannot add any non-zero 
		//			 element again unless you recreate a new system!
		cs_spfree(triplet);
		triplet = NULL;
		// -------------------------------------------------------------

		AT = cs_transpose(A , 1);

		if(AT == NULL) printf("AT fail\n");
		
		ATA = cs_multiply(AT , A);

		if(ATA == NULL) printf("ATA fail\n");

		// release AT
		cs_spfree(AT);

		Is_System_Stable = true;
	}

	void ATbComputation()
	{
		int *AP = A->p , *AI = A->i;
		float *AX = A->x;

		for (int i = 0 ; i < cols ; i++)
			ATb[i] = 0.0f;

		for (unsigned i = 0 ; i < A->n ; i++)
			for (unsigned j = AP[i] ; j < AP[i + 1] ; j++)
				ATb[i] += AX[j] * b[AI[j]];			// row = AI[j];	 col = i;  val = AX[j];

		Is_RHS_Stable = true;
	}

	void ConjugateGradient(float epsilon = 0.001f , int max_iter = 15000)
	{
		float *r = new float[cols];
		float *d = new float[cols];
		float *Ad = new float[cols];
		float *h = new float[cols];
		float *diag_inv = new float[cols];


		for (int i = 0 ; i < cols ; i++)
			r[i] = d[i] = Ad[i] = h[i] = diag_inv[i] = 0.0f;

		// diagonal inverse
		for (int i = 0 ; i < ATA->n ; i++)
			for (int j = ATA->p[i] ; j < ATA->p[i + 1] ; j++)
			{
				if (ATA->i[j] == i)
				{
					diag_inv[i] = ATA->x[j];
					break;
				}
				else if (ATA->i[j] > i)
					break;
			}

		for(int i = 0; i < cols ; i++)
			diag_inv[i] = (float)((i >= cols || diag_inv[i] == 0.0) ? 1.0 : 1.0 / diag_inv[i]) ;

		// r = A*x
		cs_gaxpy(ATA , x , r);

		// r = b - A*x
		VecAdd(r , -1.0f , ATb , 1.0f , cols);

		// d = M-1 * r
		VecVecMult(diag_inv , r , d , cols);

		// cur_err = rT*d
		float cur_err = VecVecDot(r , d , cols);

		// err
		float err = (float)(cols * epsilon * epsilon);

		int its = 0;
		while ( cur_err > err && (int)its < max_iter) 
		{
			// Ad = A*d
			memset(Ad , 0 , cols * sizeof(float));
			cs_gaxpy(ATA , d , Ad);

			// alpha = cur_err / (dT*Ad)
			float alpha = cur_err / VecVecDot(d , Ad , cols);

			// x = x + alpha * d
			VecAdd(x , 1.0f , d , alpha , cols);

			// r = r - alpha * Ad
			VecAdd(r , 1.0f , Ad , -alpha , cols);

			// h = M-1r
			VecVecMult(diag_inv , r , h , cols);

			float old_err = cur_err ;

			// cur_err = rT * h
			cur_err = VecVecDot(r , h , cols);

			float beta = cur_err / old_err ;

			// d = h + beta * d
			VecAdd(d , beta , h , 1.0f , cols);
			
			its++;
		}

		if(its > 100) printf("\tits : %d \n",its);

		delete [] r;
		delete [] d;
		delete [] Ad;
		delete [] h;
		delete [] diag_inv;
	}

	void VecAdd(float *a , float alpha , float *b , float beta , int size)	// a = alpha * a + beta * b
	{
		for (int i = 0 ; i < size ; i++)
			a[i] = a[i] * alpha + b[i] * beta;
	}

	void VecVecMult(float *a , float *b , float *c , int size)				// c = a * b
	{
		for (int i = 0 ; i < size ; i++)
			c[i] = a[i] * b[i];
	}

	float VecVecDot(float *a , float *b , int size)							// return a \cdot b
	{
		float sum = 0.0f;

		for (int i = 0 ; i < size ; i++)
			sum += a[i] * b[i];

		return sum;
	}
};

#endif